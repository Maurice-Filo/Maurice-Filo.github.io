function [Hxx, Hxu, Hux, Huu] = fHessians_Bilinear(~, ~, ~, f_Parameters)
% This function computes the partial second derivatives of f(x,u) with respect to x and
% u for the bilinear systems evaluated at (x_k,u_k,t), that is
%       Hxx = \frac{\partial^2}{\partial _{xx}} f(x_k,u_k)
%       Hux = \frac{\partial^2}{\partial _{xux}} f(x_k,u_k)
%       Hxu = \frac{\partial^2}{\partial _{xu}} f(x_k,u_k)
%       Huu = \frac{\partial^2}{\partial _{uu}} f(x_k,u_k)
% Note that in general these are 3D Matrices
B = f_Parameters.B;
N = size(B,1);
Hxx = zeros(N,N,N);
Hxu = reshape(B', N, 1, N);
Hux = reshape(B', 1, N, N);
Huu = zeros(1,1,N);
end

