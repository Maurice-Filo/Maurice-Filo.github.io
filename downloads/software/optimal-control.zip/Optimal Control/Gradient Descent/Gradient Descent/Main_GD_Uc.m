%% Clear Workspace
close all;
clear;
clc

%% Specifying the Application
% f = @f_LTI;
% fJacobians = @fJacobians_LTI;
% [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_LTI();
% N_Inputs = 1;

% f = @f_LTI_Distributed;
% fJacobians = @fJacobians_LTI_Distributed;
% [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_LTI_Distributed();
% N_Inputs = 1;

% f = @f_Bilinear;
% fJacobians = @fJacobians_Bilinear;
% [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Bilinear();
% N_Inputs = 1;

f = @f_Chemical;
fJacobians = @fJacobians_Chemical;
[f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Chemical();
N_Inputs = 1;

% f = @f_Oscillator;
% fJacobians = @fJacobians_Oscillator;
% [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Oscillator();
% N_Inputs = 1;

% f = @f_Heat_Moving_Source;
% fJacobians = @fJacobians_Heat_Moving_Source;
% [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Heat_Moving_Source();
% N_Inputs = 2;

%% Gradient Descent Algorithm Parameters
Nt = length(t_vector) - 2;
u_0 = ones(N_Inputs,Nt+2);                          % Initial Guess for the control
beta = 0.3; tau = 0.5; Step0 = 1;                   % Parameters for Armijo-Backtrack
kmax = 100;                                         % Maximum number of iterations for GD algorithm
NORMTOL = 1e-6;                                     % Tolerance of the Norm of the Gradient
Step_Min = 1e-14;                                   % Minimum Step Size

%% Gradient Descent
muT = 0 * x0;
J = zeros(kmax,1);
NORM = 1;
k = 1;      
Step_History = zeros(1,kmax);
u_k = u_0;
Step_k = Step_Min + 1;
while(NORM > NORMTOL) && (k <= kmax) && (Step_k > Step_Min)
    x_k = StateEquation(t_vector, u_k, x0, f, f_Parameters);
    J_k = ComputePerformanceIndex(t_vector, x_k, u_k, Q, R);
    [Gradient_k, ~] = Gradient_Uc(Q, R, u_k, x_k, t_vector, muT, fJacobians, f_Parameters);
    du_k = - Gradient_k;
    Step_k = ArmijoBacktrack_Uc(tau, beta, Step0, du_k, Gradient_k, Q, R, t_vector, u_k, x0, f, f_Parameters);
    u_k = u_k + Step_k * du_k;
    NORM = InnerProduct(Gradient_k, Gradient_k, t_vector);
    Step_History(k) = Step_k;
    J(k) = J_k;
    k = k+1;
    k
end
J(k:end) = [];
Step_History(k:end) = [];
u = u_k;
x = StateEquation(t_vector, u, x0, f, f_Parameters);

%% Plot Results
LineWidth = 2;
FontSize = 12;
figure();
Handle_1 = subplot(2,2,1);
    plot(Handle_1, t_vector, x, 'LineWidth', LineWidth);
    Handle_1.XGrid = 'on';
    Handle_1.YGrid = 'on';
    Handle_1.XMinorGrid = 'on';
    Handle_1.YMinorGrid = 'on';
    Handle_1.XLabel.String = 'Time';
    Handle_1.YLabel.String = 'State Variables';
    Handle_1.XLim = [0 t_vector(end)];
    Handle_1.FontSize = FontSize;

Handle_2 = subplot(2,2,2);
    plot(Handle_2, t_vector, u, 'color', 'k', 'LineWidth', LineWidth);
    Handle_2.XGrid = 'on';
    Handle_2.YGrid = 'on';
    Handle_2.XMinorGrid = 'on';
    Handle_2.YMinorGrid = 'on';
    Handle_2.XLabel.String = 'Time';
    Handle_2.YLabel.String = 'Inputs';
    Handle_2.XLim = [0 t_vector(end)];
    Handle_2.FontSize = FontSize;

Handle_3 = subplot(2,2,3);
    plot(Handle_3, 1:length(J), J, 'color', 'k', 'LineWidth', LineWidth);
    Handle_3.XGrid = 'on';
    Handle_3.YGrid = 'on';
    Handle_3.XMinorGrid = 'on';
    Handle_3.YMinorGrid = 'on';
    Handle_3.XLabel.String = 'Iterations';
    Handle_3.YLabel.String = 'Performance Index';
    Handle_3.XLim = [1, length(J)];
    Handle_3.FontSize = FontSize;
    Handle_3.YScale = 'log';

Handle_4 = subplot(2,2,4);
    plot(Handle_4, 1:length(Step_History), Step_History, 'color', 'k', 'LineWidth', LineWidth);
    Handle_4.XGrid = 'on';
    Handle_4.YGrid = 'on';
    Handle_4.XMinorGrid = 'on';
    Handle_4.YMinorGrid = 'on';
    Handle_4.XLabel.String = 'Iterations';
    Handle_4.YLabel.String = 'Step Size';
    Handle_4.XLim = [1, length(Step_History)];
    Handle_4.FontSize = FontSize;
    Handle_4.YScale = 'log';