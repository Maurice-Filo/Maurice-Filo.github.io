%% Clear Workspace
close all;
clear;
clc;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Ranges and Step Size for Vector Fields
dx = 0.1; dy = 0.1;
xLow = -3; xHigh = 3;
yLow = -3; yHigh = 3;
x_vector = xLow : dx : xHigh;
y_vector = yLow : dy : yHigh;
[x_mesh, y_mesh] = meshgrid(x_vector, y_vector);

%% Simulation Parameters
tf = 20;
dt = 0.01;
t_vector = 0 : dt : tf;
x0_vector = [-2.2 : 0.2 : 2.2, -1.4142, 1.4142];
y0_vector = 0 * x0_vector;

%% Plotting the Vector Field
[dx_mesh, dy_mesh] = f(x_mesh, y_mesh);
figure();
dx_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dx_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
dy_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dy_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
quiver(x_vector, y_vector, dx_mesh_Normalized, dy_mesh_Normalized, 0);
axes1_h = gca;
% Axis Properties
    hold(axes1_h, 'on');  
    axes1_h.XLim = [xLow, xHigh];
    axes1_h.YLim = [yLow, yHigh];
    axes1_h.FontSize = 24;
    grid(axes1_h, 'on');
        % Axis Title Properties
        axes1_h.Title.String = 'Trajectories';
        axes1_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes1_h.XLabel.String = '$x$';
        axes1_h.YLabel.String = '$y$';

%% Simulations
x = zeros(length(x0_vector), length(t_vector));
y = x;
Options = odeset('reltol', 1e-5);
for i = 1 : length(x0_vector)
    IC = [x0_vector(i); y0_vector(i)];
    [~, X] = ode45(@(t,X) f_ODE(t, X), t_vector, IC, Options);
    X = X';
    x(i,:) = X(1,:); y(i,:) = X(2,:);
end
for i = 1 : length(x0_vector)
    plot(x(i,:), y(i,:), 'LineWidth', 2, 'Color', 'k');
    hold on
end

%% Function for ODE
function dX = f_ODE(t, X)
    [dx, dy] = f(X(1), X(2));
    dX = [dx; dy];
end


%% Function for Double-Well System
function [dx, dy] = f(x,y)
    dx = y;
    dy = x - x.^3;
end