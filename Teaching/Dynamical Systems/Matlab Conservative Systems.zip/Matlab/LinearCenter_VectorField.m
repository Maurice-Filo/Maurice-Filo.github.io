%% Clear Workspace
close all;
clear;
clc;

%% Ranges and Step Size for Vector Fields
dx = 0.1; dy = 0.1;
xLow = -5; xHigh = 5;
yLow = -5; yHigh = 5;
x_vector = xLow : dx : xHigh;
y_vector = yLow : dy : yHigh;
[x_mesh, y_mesh] = meshgrid(x_vector, y_vector);

%% Simulation Parameters
tf = 20;
dt = 0.01;
t_vector = 0 : dt : tf;
x0_vector = [1 2 3];
y0_vector = [1 2 3];

%% Plotting the Vector Field
[dx_mesh, dy_mesh] = f(x_mesh, y_mesh);
figure();
dx_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dx_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
dy_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dy_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
axes1_h = subplot(3,2,[1 3 5]);
quiver(x_vector, y_vector, dx_mesh_Normalized, dy_mesh_Normalized, 0);
% Axis Properties
    hold(axes1_h, 'on');  
    axes1_h.XLim = [xLow, xHigh];
    axes1_h.YLim = [yLow, yHigh];
    axes1_h.FontSize = 24;
    grid(axes1_h, 'on');
        % Axis Title Properties
        axes1_h.Title.String = 'Trajectories';
        axes1_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes1_h.XLabel.String = '$x$';
        axes1_h.YLabel.String = '$y$';

%% Simulations
x = zeros(length(x0_vector), length(t_vector));
y = x;
Options = odeset('reltol', 1e-5);
for i = 1 : length(x0_vector)
    IC = [x0_vector(i); y0_vector(i)];
    [~, X] = ode45(@(t,X) f_ODE(t, X), t_vector, IC, Options);
    X = X';
    x(i,:) = X(1,:); y(i,:) = X(2,:);
end

%% Plotting the Results
Colors = ['k', 'r', 'm'];
for i = 1 : length(x0_vector)
    plot(x(i,:), y(i,:), 'LineWidth', 2, 'Color', Colors(i));
    hold on
end
legend('Vector Field', 'Trajectory 1, IC = (1,1)', 'Trajectory 2, IC = (2,2)', 'Trajectory 3, IC = (3,3)');
axes2_h = subplot(3,2,2);
% Axis Properties
    hold(axes2_h, 'on');  
    axes2_h.XLim = [0, tf];
    axes2_h.YLim = [min([x(1,:), y(1,:)]), max([x(1,:), y(1,:)])];
    axes2_h.FontSize = 24;
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.String = 'Initial Condition (1,1)';
        axes2_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.String = '$t$';
        axes2_h.YLabel.String = '$x(t), y(t)$';
plot(axes2_h, t_vector, x(1,:), 'LineWidth', 2, 'Color', Colors(1));
plot(axes2_h, t_vector, y(1,:), 'LineWidth', 2, 'COlor', Colors(1), 'LineStyle', '-.');
legend('$x(t)$', '$y(t)$');

axes3_h = subplot(3,2,4);
% Axis Properties
    hold(axes3_h, 'on');  
    axes3_h.XLim = [0, tf];
    axes3_h.YLim = [min([x(2,:), y(2,:)]), max([x(2,:), y(2,:)])];
    axes3_h.FontSize = 24;
    grid(axes3_h, 'on');
        % Axis Title Properties
        axes3_h.Title.String = 'Initial Condition (2,2)';
        axes3_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes3_h.XLabel.String = '$t$';
        axes3_h.YLabel.String = '$x(t), y(t)$';
plot(axes3_h, t_vector, x(2,:), 'LineWidth', 2, 'Color', Colors(2));
plot(axes3_h, t_vector, y(2,:), 'LineWidth', 2, 'COlor', Colors(2), 'LineStyle', '-.');
legend('$x(t)$', '$y(t)$');

axes4_h = subplot(3,2,6);
% Axis Properties
    hold(axes4_h, 'on');  
    axes4_h.XLim = [0, tf];
    axes4_h.YLim = [min([x(3,:), y(3,:)]), max([x(3,:), y(3,:)])];
    axes4_h.FontSize = 24;
    grid(axes4_h, 'on');
        % Axis Title Properties
        axes4_h.Title.String = 'Initial Condition (3,3)';
        axes4_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes4_h.XLabel.String = '$t$';
        axes4_h.YLabel.String = '$x(t), y(t)$';
plot(axes4_h, t_vector, x(3,:), 'LineWidth', 2, 'Color', Colors(3));
plot(axes4_h, t_vector, y(3,:), 'LineWidth', 2, 'COlor', Colors(3), 'LineStyle', '-.');
legend('$x(t)$', '$y(t)$');

%% Constant Energy
figure()
plot(t_vector, 0.5*(x(1,:).^2 + y(1,:).^2), 'LineWidth', 2, 'Color', Colors(1));
hold on
plot(t_vector, 0.5*(x(2,:).^2 + y(2,:).^2), 'LineWidth', 2, 'Color', Colors(2));
plot(t_vector, 0.5*(x(3,:).^2 + y(3,:).^2), 'LineWidth', 2, 'Color', Colors(3));
axes5_h = gca;
% Axis Properties
    axes5_h.XLim = [0, tf];
    axes5_h.YLim = [0 10];
    axes5_h.FontSize = 24;
    grid(axes5_h, 'on');
        % Axis Title Properties
        axes5_h.Title.String = '$E(x,y) = \frac{1}{2}(x^2 + y^2)$';
        axes5_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes5_h.XLabel.String = '$t$';
        axes5_h.YLabel.String = '$E\big(x(t), y(t)\big)$';


%% Function for ODE
function dX = f_ODE(t, X)
    [dx, dy] = f(X(1), X(2));
    dX = [dx; dy];
end


%% Function for RHS
function [dx, dy] = f(x,y)
    dx = y;
    dy = -x;
end