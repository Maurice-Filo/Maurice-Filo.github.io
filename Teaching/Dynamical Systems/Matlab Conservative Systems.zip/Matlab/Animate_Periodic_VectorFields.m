%% Clear Workspace
close all;
clear;
clc;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Ranges and Step Size for Vector Fields
dx = 0.1; dy = 0.1;
xLow = -3; xHigh = 3;
yLow = -3; yHigh = 3;
x_vector = xLow : dx : xHigh;
y_vector = yLow : dy : yHigh;
[x_mesh, y_mesh] = meshgrid(x_vector, y_vector);

%% Simulation Parameters
tf = 20;
dt = 0.1;
t_vector = 0 : dt : tf;
IC = [1,0.5];
% IC = [-1,0.5];
% IC = [2,0];
% IC = [sqrt(2),0];
% IC = [0.00001,0];

%% Plotting the Vector Field
[dx_mesh, dy_mesh] = f(x_mesh, y_mesh);
figure();
q_handle = quiver(x_vector, y_vector, dx_mesh, dy_mesh);
pause();
figure();
dx_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dx_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
dy_mesh_Normalized = 0.5*sqrt(dx^2 + dy^2) * dy_mesh ./ sqrt(dx_mesh.^2 + dy_mesh.^2); 
axes1_h = subplot(1,2,1);
quiver(x_vector, y_vector, dx_mesh_Normalized, dy_mesh_Normalized, 0);
% Axis Properties
    hold(axes1_h, 'on');  
    axes1_h.XLim = [xLow, xHigh];
    axes1_h.YLim = [yLow, yHigh];
    axes1_h.FontSize = 24;
    grid(axes1_h, 'on');
        % Axis Title Properties
        axes1_h.Title.String = 'Trajectories in Phase Plane';
        axes1_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes1_h.XLabel.String = '$x$';
        axes1_h.YLabel.String = '$y$';
axes2_h = subplot(1,2,2);
% Axis Properties
    hold(axes2_h, 'on');  
    axes2_h.XLim = [0, tf];
    axes2_h.YLim = [min(xLow,yLow), max(xHigh,yHigh)];
    axes2_h.FontSize = 24;
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.String = 'Trajectories in Time';
        axes2_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.String = '$t$';
        axes2_h.YLabel.String = '$x(t), y(t)$';

%% Simulation
Options = odeset('reltol', 1e-7);
[~, X] = ode45(@(t,X) f_ODE(t, X), t_vector, IC, Options);
X = X';
x = X(1,:); y = X(2,:);

%% Animation
plot(axes2_h, t_vector(1), x(1), 'b', 'LineWidth', 2);
plot(axes2_h, t_vector(1), y(1), 'r', 'LineWidth', 2);
legend(axes2_h, '$x(t)$', '$y(t)$', 'AutoUpdate','off');
scatter_h = plot(axes1_h, x(1), y(1), 'ko', 'MarkerFaceColor', 'k', 'MarkerSize', 20);
pause();
for i = 2 : length(t_vector)
    plot(axes1_h, [x(i-1) x(i)], [y(i-1) y(i)], 'k', 'LineWidth', 2);
    plot(axes2_h, [t_vector(i-1) t_vector(i)], [x(i-1) x(i)], 'b', 'LineWidth', 2);
    plot(axes2_h, [t_vector(i-1) t_vector(i)], [y(i-1) y(i)], 'r', 'LineWidth', 2);
    scatter_h.XData = x(i); scatter_h.YData = y(i);
    drawnow();
    FileName = ['InnerRight', num2str(i)];
h_figure = gcf;
h_figure.PaperPositionMode = 'auto';
fig_pos = h_figure.PaperPosition;
h_figure.PaperSize = [fig_pos(3) fig_pos(4)];
print(h_figure, FileName,'-dpdf', '-r0');
end

%% Function for ODE
function dX = f_ODE(t, X)
    [dx, dy] = f(X(1), X(2));
    dX = [dx; dy];
end


%% Function for Double-Well System
function [dx, dy] = f(x,y)
    dx = y;
    dy = x - x.^3;
end