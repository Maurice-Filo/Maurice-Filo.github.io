function [t_vector, x_Solutions, y_Solutions] = VectorField_2D(fString, gString, Range, dx, dy, N, tf)
%% Creating the Right Hand Side Function
syms x y real
f(x,y) = eval(fString);
g(x,y) = eval(gString);
F = matlabFunction(f, g);

%% Drawing the Vector Field
figure();
xLow = Range(1); xHigh = Range(2); yLow = Range(3); yHigh = Range(4);
x_vector = xLow : dx : xHigh; y_vector = yLow : dy : yHigh;
[x_mesh, y_mesh] = meshgrid(x_vector, y_vector);
[dxdt_mesh, dydt_mesh] = F(x_mesh, y_mesh);
quiver(x_vector, y_vector, dxdt_mesh, dydt_mesh); hold on;
% quiver(x_vector, y_vector, 0.1*dxdt_mesh ./ sqrt(dxdt_mesh.^2 + dydt_mesh.^2), 0.1*dydt_mesh./ sqrt(dxdt_mesh.^2 + dydt_mesh.^2), 'AutoScale', 'off'); hold on;

%% Drawing the Nullclines
% x_vector_fine = 0 : dx/100 : xHigh;
% y_vector_fine = 0 : dy/100 : yHigh;
% F_1 = matlabFunction(f);
% F_2 = matlabFunction(g);
% 
% for i = 1 : length(x_vector_file)
% 
% end
% 
% 
% keyboard

%% Creating approximately N Initial Conditions
N = round(sqrt(N));
x0_vector = linspace(xLow, xHigh, N);
y0_vector = linspace(yLow, yHigh, N);

%% Simulations
f_func = matlabFunction(f);
g_func = matlabFunction(g);
f_ODE = @(t,z) [f_func(z(1), z(2)); g_func(z(1), z(2))];
t_vector = linspace(0, tf, 1000);
x_Solutions = zeros(N^2, length(t_vector));
y_Solutions = x_Solutions;
counter = 1;
Options = odeset('RelTol', 1e-10);
for i = 1 : length(x0_vector)
    for j = 1 : length(y0_vector)
        IC = [x0_vector(i); y0_vector(j)];
        [~, X] = ode45(@(t,X)f_ODE(t,X), t_vector, IC, Options);
        if size(X,1) < length(t_vector)
            X = [X; repmat(X(end,:), length(t_vector) - size(X,1), 1)];
        end
        x_Solutions(counter,:) = X(:,1)';
        y_Solutions(counter,:) = X(:,2)';
        plot(x0_vector(i), y0_vector(j), 'ro', 'MarkerSize', 5);
        plot(x_Solutions(counter,:), y_Solutions(counter,:), 'LineWidth', 2, 'Color', 'k');
        counter = counter + 1;
        drawnow();
        axis([xLow xHigh yLow yHigh]);
    end
end

end

