%% Description
% This script creates a video that describes how f(x,r) varies while r is
% varied. It also simultaneously plots the bifurcation diagram.
%
% --- Maurice Filo, 24.10.2018
%
%% User Input:
% First, code the function f(t,x,r) for your dynamical system:
% dx/dt = f(t,x,r) in the separate m-file called f_VectorField, where 
%               - x is the (one dimensional) state variable
%               - t is time
%               - r is a bifurcation parameter.
%
% Then, specify the ranges to be considered for the bifurcation parameter r,
% the ranges for plotting f(x,r), and the pause between subsequent plots.

%% Clear Workspace
close all;
clear;
clc;

%% Ranges for Parameters and Plots
% For f(x) = r + x^2  (Saddle-Node Bifurcation)
% f_string = '$\dot x = r + x^2$';
% rLow = -0.5;        rHigh = 0.5;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -1;          yHigh = 3;          Pause = 0;

% % For f(x) = rx - x^2 (Transcritical Bifurcation)
% f_string = '$\dot x = rx - x^2$';
% rLow = -0.5;        rHigh = 0.5;        dr = 0.01;   
% xLow = -1;          xHigh = 1;          dx = 0.01;
% yLow = -0.3;        yHigh = 0.3;        Pause = 0;

% % For f(x) = rx - x^3 (Supercritical Pitchfork Bifurcation)
% f_string = '$\dot x = rx - x^3$';
% rLow = -0.5;        rHigh = 0.5;        dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;        Pause = 0;

% % Ranges for f(x) = x.^2 ./ (1 + x.^2) - r * x .  (Gene Expression)

f_string = '$\dot x = \frac{x^2}{1+x^2} - rx$';
rLow = 1;           rHigh = 4;              dr = 0.01;   
xLow = 0;           xHigh = 10;             dx = 0.01;
yLow = -3;        yHigh = 3;            Pause = 0;


%% Plotting f(x,r) and the Bifurcation Diagram for each r.
f = @f_VectorField;
r_vector = rLow : dr : rHigh;
x_vector = xLow : dx : xHigh;
% Create Figure
figure_h = figure();
    % Figure Properties
    figure_h.Units = 'normalized';
    figure_h.Position = [0.1, 0.1, 0.8, 0.8];    
% Axis Properties
axes1_h = subplot(2,1,1);
    hold(axes1_h, 'on');  
    axes1_h.XLim = [xLow, xHigh];
    axes1_h.YLim = [yLow, yHigh];
    axes1_h.FontSize = 24;
    grid(axes1_h, 'on');
        % Axis Title Properties
        axes1_h.Title.Interpreter = 'latex';
        axes1_h.Title.String = [f_string, ',  $r$ = ', num2str(r_vector(1))];
        axes1_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes1_h.XLabel.String = '$x$';
        axes1_h.YLabel.String = '$f(x)$';
        axes1_h.XLabel.Interpreter = 'latex';
        axes1_h.YLabel.Interpreter = 'latex';
axes2_h = subplot(2,1,2);
    hold(axes2_h, 'on');  
    axes2_h.XLim = [rLow, rHigh];
    axes2_h.YLim = [xLow, xHigh];
    axes2_h.FontSize = 24;
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.Interpreter = 'latex';
        axes2_h.Title.String = ['\textbf{Bifurcation Diagram of} ' f_string];
        axes_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.Interpreter = 'latex';
        axes2_h.YLabel.Interpreter = 'latex';
        axes2_h.XLabel.String = '$r$';
        axes2_h.YLabel.String = '$x^*$';
% Horizontal Line
curve1_h = plot(axes1_h, x_vector, 0*x_vector);
    % Line Properties
    curve1_h.LineWidth = 1;
    curve1_h.Color = 'red';
% f(x) curve
curve2_h = plot(axes1_h, x_vector, f([], x_vector, r_vector(1)));
    % Line Properties
    curve2_h.LineWidth = 2;
    curve2_h.Color = 'blue';
% Bifurcation Diagram Scatter
    y = f([],x_vector,r_vector(1));
    [Stable_FP, Unstable_FP] = find_FP(x_vector,y);
    scatter(axes2_h, r_vector(1) * ones(length(Stable_FP),1), Stable_FP, 10, 'bo', 'LineWidth', 10); 
    scatter(axes2_h, r_vector(1) * ones(length(Unstable_FP),1), Unstable_FP, 10, 'ro', 'LineWidth', 10);
    legend(axes2_h, 'Stable Fixed Point', 'Unstable Fixed Point', 'AutoUpdate','off');
    pause();
for i = 2 : length(r_vector)
    y = f([],x_vector,r_vector(i));
    [Stable_FP, Unstable_FP] = find_FP(x_vector,y);
    curve2_h.YData = y;
    axes1_h.Title.String = ['$r$ = ', num2str(r_vector(i))];  
    scatter(axes2_h, r_vector(i) * ones(length(Stable_FP),1), Stable_FP, 10, 'bo', 'LineWidth', 10); 
    scatter(axes2_h, r_vector(i) * ones(length(Unstable_FP),1), Unstable_FP, 10, 'ro', 'LineWidth', 10);
    drawnow();
end


%% Function for finding fixed points (zero-crossing of f)
function [Stable_FP, Unstable_FP] = find_FP(x,y)
    FP_Indeces = find(y .* circshift(y, -1) <= 0);        % Find the zero-crossing
    if y(1) * y(end) <= 0
        FP_Indeces(end) = [];
    end
    dy = diff(y);
    Stable_FP = [];
    Unstable_FP = [];
    for k = 1 : length(FP_Indeces)
        if dy(FP_Indeces(k)) < 0
            Stable_FP = [Stable_FP; x(FP_Indeces(k))];
        else
            Unstable_FP = [Unstable_FP; x(FP_Indeces(k))];
        end
    end
end

