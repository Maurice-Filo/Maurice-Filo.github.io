%% Description
% This script creates a video that describes how f(x,r) varies while r is
% varied.
%
% --- Maurice Filo, 24.10.2018
%

%% User Input
% First, code the function f(t,x,r) for your dynamical system:
% dx/dt = f(t,x,r) in the separate m-file called f_VectorField, where 
%               - x is the (one dimensional) state variable
%               - t is time
%               - r is a bifurcation parameter.
%
% Then, specify the ranges to be considered for the bifurcation parameter r,
% the ranges for plotting f(x,r), and the pause between subsequent plots.

%% Clear Workspace
close all;
clear;
clc

%% Ranges for Parameters and Plots
% % For f(x) = r + x^2  (Saddle-Node Bifurcation)
% f_string = '$f(x) = r + x^2$';
% rLow = -1;          rHigh = 1;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -1;          yHigh = 3;          Pause = 0;

% % For f(x) = rx - x^2 (Transcritical Bifurcation)
% f_string = '$f(x) = rx - x^2$';
% rLow = -1;          rHigh = 1;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;        Pause = 0;

% % For f(x) = rx - x^3 (Supercritical Pitchfork Bifurcation)
% f_string = '$f(x) = rx - x^3$';
% rLow = -1;          rHigh = 1;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;        Pause = 0;

% %  Ranges for f(x) = x.^2 ./ (1 + x.^2) - r * x .  (Gene Expression)
% f_string = '$f(x) = \frac{x^2}{1+x^2} - rx$';
% rLow = 0;           rHigh = 1;              dr = 0.01;   
% xLow = 0;           xHigh = 10;             dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;            Pause = 0;

f_string = 'test';
rLow = -2;          rHigh = 2;          dr = 0.01;   
xLow = -pi;        xHigh = pi;        dx = 0.01;
yLow = -10;          yHigh = 10;          Pause = 0;

%% Plotting in a Loop
r_vector = rLow : dr : rHigh;
x_vector = xLow : dx : xHigh;
f = @f_VectorField;
% Create Figure
figure_h = figure();
    % Figure Properties
    figure_h.Units = 'normalized';
    figure_h.Position = [0.1, 0.1, 0.8, 0.8];    
% Axis Properties
axes_h = axes();
    hold(axes_h, 'on');  
    axes_h.Position = [0.1, 0.1, 0.8, 0.8];
    axes_h.XLim = [xLow, xHigh];
    axes_h.YLim = [yLow, yHigh];
    axes_h.FontSize = 24;
    grid(axes_h, 'on');
        % Axis Title Properties
        axes_h.Title.String = [f_string, ',  $r$ = ', num2str(r_vector(1))];
        axes_h.Title.Interpreter = 'latex';
        axes_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes_h.XLabel.String = '$x$';
        axes_h.YLabel.String = '$f(x)$';
        axes_h.XLabel.Interpreter = 'latex';
        axes_h.YLabel.Interpreter = 'latex';
% Horizontal Line
curve1_h = plot(axes_h, x_vector, 0*x_vector);
    % Line Properties
    curve1_h.LineWidth = 3;
    curve1_h.Color = 'red';
% f(x) curve
curve2_h = plot(axes_h, x_vector, f([], x_vector, r_vector(1)));
    % Line Properties
    curve2_h.LineWidth = 2;
    curve2_h.Color = 'blue';
    
pause();
for i = 2 : length(r_vector)
    curve2_h.YData = f([], x_vector, r_vector(i));
    axes_h.Title.String = [f_string, ',  $r$ = ', num2str(r_vector(i))];
    drawnow();   
end