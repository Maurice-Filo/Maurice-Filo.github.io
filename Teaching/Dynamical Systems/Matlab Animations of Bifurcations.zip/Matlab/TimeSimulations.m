%% Description
% This script creates the bifurcation diagram of a one dimensional
% dynamical system and simulates the response to multiple initial
% conditions for 3 particular values of the bifucation parameter.
%
% --- Maurice Filo, 24.10.2018
%
%% User Input:
% First, code the function f(t,x,r) for your dynamical system:
% dx/dt = f(t,x,r) in the separate m-file called f_VectorField, where 
%               - x is the (one dimensional) state variable
%               - t is time
%               - r is a bifurcation parameter.
%
% Then, specify the ranges to be considered for the bifurcation parameter r,
% the ranges for plotting f(x,r), and the pause between subsequent plots.
%
% Finally, specify the simulation parameters:
%               - r_Particular should be a vector of 3 entries. Each entry
%               corresponds to a particular bifurcation parameter for which
%               the dynamical system is to be simulated.
%               - dt is the discretization step for plotting the solutions.
%               - tf is the final time of simulation.
%               - IC_vector is a vector that contains multiple initial
%               conditions for which the dynamical system is to be
%               simulated.

%% Clear Workspace
close all;
clear;
clc;

%% Ranges for Parameters and Plots
% For f(x) = r + x^2  (Saddle-Node Bifurcation)
f_string = '$\dot x = r + x^2$';
rLow = -1;          rHigh = 1;          dr = 0.01;   
xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
yLow = -1;          yHigh = 3;          Pause = 0;

% % For f(x) = rx - x^2 (Transcritical Bifurcation)
% f_string = '$\dot x = rx - x^2$';
% rLow = -1;          rHigh = 1;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;        Pause = 0;

% % For f(x) = rx - x^3 (Supercritical Pitchfork Bifurcation)
% f_string = '$\dot x = rx - x^3$';
% rLow = -1;          rHigh = 1;          dr = 0.01;   
% xLow = -1.5;        xHigh = 1.5;        dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;        Pause = 0;

% % Ranges for f(x) = x.^2 ./ (1 + x.^2) - r * x .  (Gene Expression)
% f_string = '$\dot x = \frac{x^2}{1+x^2} - rx$';
% rLow = 0;           rHigh = 1;              dr = 0.01;   
% xLow = 0;           xHigh = 10;             dx = 0.01;
% yLow = -0.5;        yHigh = 0.5;            Pause = 0;


r = rLow : dr : rHigh;
x = xLow : dx : xHigh;


% %% Simulation Parameters
% Initial Conditions for f(x) = r + x^2  (Saddle-Node Bifurcation)
r_Particular = [-0.1, 0, 0.1];
dt = 0.001; tf = 10;            
time_vector = 0 : dt : tf;      % Time Horizon
Colors = ['k', 'm', 'g']; 
IC_vector = -1 : 0.25 : 1; 

% % Initial Conditions for f(x) = rx - x^2 (Transcritical Bifurcation)
% r_Particular = [-0.25, 0, 0.25];
% dt = 0.001; tf = 10;            
% time_vector = 0 : dt : tf;      % Time Horizon
% Colors = ['k', 'm', 'g'];
% IC_vector = -1 : 0.125 : 1; 

% % Initial Conditions for f(x) = rx - x^3 (Supercritical Pitchfork Bifurcation)
% r_Particular = [-0.25, 0, 0.25];
% dt = 0.001; tf = 10;            
% time_vector = 0 : dt : tf;      % Time Horizon
% Colors = ['k', 'm', 'g'];
% IC_vector = -1 : 0.125 : 1; 

% % Initial Conditions for f(x) = x.^2 ./ (1 + x.^2) - r * x .  (Gene Expression)
% r_Particular = [0.4, 0.5, 0.6];
% dt = 0.01; tf = 30;            
% time_vector = 0 : dt : tf;      % Time Horizon
% Colors = ['k', 'm', 'g']; 
% IC_vector = 0 : 0.25 : 3;  



%% Bifurcation Diagram
figure();
subplot(3,2,[1, 3, 5]);
f = @f_VectorField;
for i = 1 : length(r)
    y = f([],x,r(i));
    [Stable_FP, Unstable_FP] = find_FP(x,y); 
    scatter(r(i) * ones(length(Stable_FP),1), Stable_FP, 10, 'bo', 'LineWidth', 10); hold on
    scatter(r(i) * ones(length(Unstable_FP),1), Unstable_FP, 10, 'ro', 'LineWidth', 10); 
end
title(['Bifurcation Diagram of ', f_string], 'Fontsize', 30, 'interpreter', 'latex'); 
axis([rLow rHigh xLow xHigh]);
xlabel('$r$', 'Fontsize', 20, 'interpreter', 'latex');
ylabel('$x^*$', 'Fontsize', 20, 'interpreter', 'latex'); 
set(gca, 'FontSize', 24); 
grid on
leg = legend('Stable Fixed Points', 'Unstable Fixed Points');
set(leg, 'interpreter', 'latex', 'FontSize', 16); 
pause();

%% Simulations
for k = 1 : 3
    r0 = r_Particular(k); 
    subplot(3,2,[1,3,5]);
    plot(r0 * ones(2,1), [xLow, xHigh], [Colors(k), '-.'], 'Linewidth', 1); 
    leg = legend('Stable Fixed Points', 'Unstable Fixed Points');
    pause();
    X = zeros(length(time_vector), length(IC_vector));          % Storage Array for Solutions to different Initial Conditions
    for i = 1 : length(IC_vector)
        [~, x] = ode45(@(t, x) f(t, x, r0), time_vector, IC_vector(i));   
        X(1:length(x),i) = x; X(length(x)+1:end,i) = x(end);
    end
    subplot(3,2,2*k);
    Plot_Solutions(time_vector, X, xLow, xHigh, Colors(k), r0);
    pause();
end


%% Function for Plotting Solutions
function Plot_Solutions(time_vector, X, xLow, xHigh, color, gamma)
    plot(time_vector, X, 'LineWidth', 2, 'color', color);
    grid on;
    xlabel('$t$', 'interpreter', 'latex', 'FontSize', 30);
    ylabel('$x(t)$', 'interpreter', 'latex', 'FontSize', 30);
    set(gca, 'FontSize', 24);
    title(['Response to Different ICs for $r$ = ', num2str(gamma)], 'interpreter', 'latex', 'FontSize', 26);
    axis([0, time_vector(end), xLow, xHigh]);
end

%% Function for finding fixed points (zero-crossing of f)
function [Stable_FP, Unstable_FP] = find_FP(x,y)
    FP_Indeces = find(y .* circshift(y, -1) <= 0);        % Find the zero-crossing
    if y(1) * y(end) <= 0
        FP_Indeces(end) = [];
    end
    dy = diff(y);
    Stable_FP = [];
    Unstable_FP = [];
    for k = 1 : length(FP_Indeces)
        if dy(FP_Indeces(k)) < 0
            Stable_FP = [Stable_FP; x(FP_Indeces(k))];
        else
            Unstable_FP = [Unstable_FP; x(FP_Indeces(k))];
        end
    end
end