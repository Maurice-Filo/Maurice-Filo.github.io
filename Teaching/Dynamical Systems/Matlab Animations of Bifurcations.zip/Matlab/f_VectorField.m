function dx = f_VectorField(t,x,r)
%This function codes the vector field of the dynamical system 
% dx/dt = f(x,r) in the separate m-file called f_VectorField, where 
%               - x is the (one dimensional) state variable
%               - t is time
%               - r is a bifurcation parameter
  
%     dx = r + x.^2;                              % Saddle Node Bifurcation
%     dx = r*x - x.^2;                            % Transcritical Bifurcation
%     dx = r*x - x.^3;                            % Pitchfork Bifurcation (Supercritical)
%     dx = x.^2 ./ (1 + x.^2) - r * x;            % Gene Expression 
dx = sin(x) ./ (r + sin(x));
end


