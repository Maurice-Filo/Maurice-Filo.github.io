%% Description
% This script shows an animation of a dynamical system evolving on a circle.

%% User Input:
% First, code the periodic function f(t,theta,r) for your dynamical system:
% dtheta/dt = f(t,theta,r), where 
%               - theta is the (one dimensional) state variable that
%               evolves on a circle.
%               - t is time
%               - r is a parameter.
% The function is located at the bottom of this m-file.
% Then, specify the simulation parameters  :
%               - r.
%               - dt is the discretization step for plotting the solutions.
%               - tf is the final time of simulation.
%               - IC is the initial condition.

%% Clear Workspace and Set Interpreter to Latex
close all;
clc;
clear;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Vector Field for Title
f_String = '$f(\theta) = \omega - a\sin(\theta)$';


%% Simulation Parameters
% Parameters for f(theta) = omega - a sin(theta)
omega = 1; a = 0.993; r = [omega, a];
dt = 0.001; tf = 120;            
t = 0 : dt : tf;      % Time Horizon
IC = pi; 

%% Vector Field
theta_vector = -pi : 0.01 : pi;
f_vector = PeriodicFunction([], theta_vector, r);

%% Simulation
[~, theta] = ode45(@(t, theta) PeriodicFunction(t, theta, r), t, IC);
theta_t = theta(1:900:end);
t = t(1:900:end);

%% Animation
theta_t = wrapToPi(theta_t);
tf = t(end);
radius = 1;

% Normalize Vector Field
normalize = 4 * max(abs(max(f_vector)), abs(min(f_vector)));
if normalize ~= 0
    f_vector_normalized = f_vector / normalize;
end

%% Create Figure
figure_h = figure();
    % Figure Properties
    figure_h.Units = 'normalized';
    figure_h.Position = [0, 0, 1, 1];
    
%% Create Polar Axes
axes1_h = polaraxes(); 
    hold(axes1_h, 'on');
%     axes1_h.TickLabelInterpreter = 'latex';
    axes1_h.Units = 'normalized';
    axes1_h.Position = [0.05, 0.4, 0.4, 0.48];
    axes1_h.RGrid = 'off';
    axes1_h.RTickLabel = [];
    axes1_h.RLim = [0 radius + radius/2];
    axes1_h.FontSize = 30;
    axes1_h.ThetaAxisUnits = 'rad';
    axes1_h.ThetaLim = [-pi, pi];
    % Axis Title Properties
        axes1_h.Title.String = '\textbf{Phase}, $\dot \theta = f(\theta)$';
        axes1_h.Title.FontSize = 30;
        
%% Create Axis for theta(t)
axes2_h = axes();
    hold(axes2_h, 'on'); 
    axes2_h.Units = 'normalized';
    axes2_h.Position = [0.55, 0.45, 0.425, 0.45];
    axes2_h.XLim = [0, tf];
    axes2_h.YLim = [-pi,pi];
    axes2_h.FontSize = 24;
    axes2_h.YTick = -pi : pi/2 : pi;
    axes2_h.YTickLabel = {'$-\pi$', '$-\frac{\pi}{2}$', '$0$','$\frac{\pi}{2}$','$\pi$'};
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.String = '\textbf{Trajectory}';
        axes2_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.String = '$t$';
        axes2_h.YLabel.String = '$\theta(t)$';
        
%% Create Axes for f(theta)
axes3_h = axes(); 
    hold(axes3_h, 'on'); 
    axes3_h.Units = 'normalized';
    axes3_h.Position = [0.25, 0.1, 0.65, 0.225];
    axes3_h.XLim = [-pi, pi];
    axes3_h.YLim = [0, max(max(f_vector))];
    axes3_h.FontSize = 24;
    axes3_h.XTick = -pi : pi/2 : pi;
    axes3_h.XTickLabel = {'$-\pi$', '$-\frac{\pi}{2}$', '$0$','$\frac{\pi}{2}$','$\pi$'};
    grid(axes3_h, 'on'); 
        % Axis Title Properties
        axes3_h.Title.String = '\textbf{Periodic Vector Field}';
        axes3_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes3_h.XLabel.String = '$\theta$';
        axes3_h.YLabel.String = '$f(\theta)$';
        
%% Draw Circles and Vector Fields
curve1_h = polarplot(axes1_h, theta_vector, radius + zeros(size(theta_vector)));
    curve1_h.Color = 'k';
    curve1_h.LineStyle = '--';
curve2_h = polarplot(axes1_h, theta_vector, radius + f_vector_normalized);
    curve2_h.Color = 'blue';
    curve2_h.LineWidth = 2;
curve3_h = plot(axes3_h, theta_vector, f_vector);
    curve3_h.Color = 'blue';
    curve3_h.LineWidth = 2;
legend_h = legend(axes3_h, f_String); 
    legend_h.Location = 'northeastoutside';
    
%% Draw Initial Condition
p_h = polarplot(axes1_h, theta_t(1), radius);
    p_h.Marker = '.';
    p_h.MarkerSize = 50;
    p_h.Color = 'blue';
curve3_h = plot(axes2_h, t(1), theta_t(1));
    curve3_h.Color = 'blue';
    curve3_h.LineWidth = 3;
    
%% Loop
pause();
for i = 2 : length(t)
    p_h.ThetaData = theta_t(i);
    curve3_h.XData = [curve3_h.XData, t(i)];
    curve3_h.YData = [curve3_h.YData, theta_t(i)];
    drawnow();
end

%% Vector Field
% Code your periodic function here. This represents the right hand side
% function of a dynamical system evolving on a circle.

% Function f(theta) = omega - a sin(theta)
function y = PeriodicFunction(t, theta, r)
omega = r(1); a = r(2);
y = omega - a*sin(theta);
end

% % Function for Phase Difference Fireflies
% function y = PeriodicFunction(t, theta, r)
% y = r - sin(theta);
% end
