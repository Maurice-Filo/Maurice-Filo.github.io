%% Description
% This script shows an animation of a dynamical system evolving on 2 circles.

%% User Input:
% First, code the periodic function f(t,theta,r) for your dynamical system:
% dtheta/dt = f(t,theta,r), where 
%               - theta is the (two dimensional) state variable. The two
%               states evolve on a circle.
%               - t is time
%               - r is a vector that holds some parameters.
% The function is located at the bottom of this m-file.
% Then, specify the simulation parameters:
%               - r.
%               - dt is the discretization step for plotting the solutions.
%               - tf is the final time of simulation.
%               - IC is the initial condition.

%% Clear Workspace and Set Interpreter to Latex
close all;
clc;
clear;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Vector Field for Title
f_String = '$\dot \theta_1 = \Omega; \quad \dot \theta_2 = \omega + A\sin(\theta_1 - \theta_2)$';

%% Simulation Parameters
% Omega = 2*pi/4; omega = 2*pi/4; A = pi/5;          % mu = 0 (Synchronization)
% Omega = 2*pi/3; omega = 2*pi/4; A = pi/5;          % 0 < mu < 1 (Phase-Locked)
Omega = 2*pi/3; omega = 2*pi/4; A = pi/7;          % mu > 1 (phase drift)
r = [Omega, omega, A];
dt = 0.1; tf = 15;            
t = 0 : dt : tf;      % Time Horizon
IC = [pi; pi/3]; 

%% Simulation
[~, theta] = ode45(@(t, theta) PeriodicFunction(t, theta, r), t, IC);
theta_t = theta';

%% Animation
Animate_Phases(t, theta_t, 1);


%% Vector Field
% Code your periodic function here. This represents the right hand side
% function of a dynamical system evolving on a circle.
function dtheta = PeriodicFunction(t, theta, r)
Omega = r(1); omega = r(2); A = r(3);
dtheta = [Omega; omega + A * sin(theta(1) - theta(2))];
end
