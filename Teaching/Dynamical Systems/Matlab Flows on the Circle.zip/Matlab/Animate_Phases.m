function [axes1_h, axes2_h] = Animate_Phases(t, theta_t, dr)
% This function animates the evolution of multiple states on the circle.
% The animations show two subplots. The first subplot shows an animation of
% multiple balls moving on concentric circles. The second plot shows the
% correspoding phase evolution in time for each ball.
% The user input are:
%       - t: a row vector containing the time horizon.
%       - theta_t: an array where each row represents the phase evaluated at
%       the corresponding time in the variable t. So theta_t can include
%       multiple variables stored in each row.
%       - dr: a positive number that corresponds to the separation of each
%       ball on the animated plot.
% The outputs are the handles for each subplot.

theta_t = wrapToPi(theta_t);
N = size(theta_t,1);
tf = t(end);
radius = 1 : dr : 1 + (N-1)*dr;
Colors = [0, 0.4470, 0.7410; 0.8500, 0.3250, 0.0980];

%% Create Figure
figure_h = figure();
    % Figure Properties
    figure_h.Units = 'normalized';
    figure_h.Position = [0, 0.3, 1, 0.5];
    
%% Create Polar Axes
axes1_h = polaraxes(); 
    hold(axes1_h, 'on');
    axes1_h.Units = 'normalized';
    axes1_h.Position = [0.05, 0.1, 0.4, 0.7];
    axes1_h.RGrid = 'off';
    axes1_h.RTickLabel = [];
    axes1_h.RLim = [0 radius(end)+ dr/2];
    axes1_h.FontSize = 24;
    axes1_h.ThetaAxisUnits = 'rad';
    axes1_h.ThetaLim = [-pi, pi];
    % Axis Title Properties
        axes1_h.Title.String = '\textbf{Phase}';
        axes1_h.Title.FontSize = 30;
        
%% Create Axis for theta(t)
axes2_h = axes();
    hold(axes2_h, 'on'); 
    axes2_h.Units = 'normalized';
    axes2_h.Position = [0.55, 0.15, 0.425, 0.7];
    axes2_h.XLim = [0, tf];
    axes2_h.YLim = [-pi, pi];
    axes2_h.FontSize = 24;
    axes2_h.YTick = -pi : pi/2 : pi;
    axes2_h.YTickLabel = {'$-\pi$', '$-\frac{\pi}{2}$', '$0$','$\frac{\pi}{2}$','$\pi$'};
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.String = '\textbf{Trajectory}';
        axes2_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.String = '$t$';
        axes2_h.YLabel.String = '$\theta(t)$';
        
%% Draw Circles
theta_vector = 0 : 0.01 : 2*pi;
for k = 1 : N
    curve1_h(k) = polarplot(axes1_h, theta_vector, radius(k) + zeros(size(theta_vector)));
        curve1_h(k).Color = 'k';
        curve1_h(k).LineStyle = '--';
    drawnow();
end

%% Draw Initial Condition
for k = 1 : N
    p_h(k) = polarplot(axes1_h, theta_t(k,1), radius(k));
        p_h(k).Marker = '.';
        p_h(k).MarkerSize = 50;
        p_h(k).Color = Colors(k,:);
    curve2_h(k) = plot(axes2_h, t(1), theta_t(k,1));
        curve2_h(k).Color = Colors(k,:);
        curve2_h(k).LineWidth = 3;
end
%% Loop
pause();
for i = 2 : length(t)
    for k = 1 : N
        p_h(k).ThetaData = theta_t(k,i);
        curve2_h(k).XData = [curve2_h(k).XData, t(i)];
        curve2_h(k).YData = [curve2_h(k).YData, theta_t(k,i)];
    end
    drawnow();
end
end

