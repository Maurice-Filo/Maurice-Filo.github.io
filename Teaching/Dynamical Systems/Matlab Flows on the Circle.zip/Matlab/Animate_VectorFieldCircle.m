%% Description
% This script creates a video that describes how f(x,r) varies while r is
% varied.
%
% --- Maurice Filo, 24.10.2018
%

%% User Input
% First, code the function f(t,x,r) for your dynamical system:
% dx/dt = f(t,x,r) in the separate m-file called f_VectorField, where 
%               - x is the (one dimensional) state variable
%               - t is time
%               - r is a bifurcation parameter.
%
% Then, specify the ranges to be considered for the bifurcation parameter r,
% the ranges for plotting f(x,r), and the pause between subsequent plots.

%% Clear Workspace
close all;
clear;
clc

%% Ranges for Parameters and Plots
% For f(theta) = omega - a sin(theta)
f_string = '$f(\theta) = \omega - a \sin(\theta) $';
rLow = -2;           rHigh = 3;          dr = 0.05;   
xLow = -pi;         xHigh = pi;         dx = 0.01;
yLow = -5;          yHigh = 5;          Pause = 0.5;

%% Plotting in a Loop
r_vector = rLow : dr : rHigh;
x_vector = xLow : dx : xHigh;
% Create Figure
figure_h = figure();
    % Figure Properties
    figure_h.Units = 'normalized';
    figure_h.Position = [0.1, 0.1, 0.8, 0.8];    
% Axis Properties
axes_h = axes();
    hold(axes_h, 'on');  
    axes_h.Position = [0.1, 0.1, 0.8, 0.8];
    axes_h.XLim = [xLow, xHigh];
    axes_h.YLim = [yLow, yHigh];
    axes_h.FontSize = 24;
    grid(axes_h, 'on');
        % Axis Title Properties
        axes_h.Title.String = [f_string, '\qquad \qquad ($\omega = 1; a$ = ', num2str(r_vector(1)), ')'];
        axes_h.Title.Interpreter = 'latex';
        axes_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes_h.XLabel.String = '$\theta$';
        axes_h.YLabel.String = '$f(\theta)$';
        axes_h.XLabel.Interpreter = 'latex';
        axes_h.YLabel.Interpreter = 'latex';
% Horizontal Line
curve1_h = plot(axes_h, x_vector, 0*x_vector);
    % Line Properties
    curve1_h.LineWidth = 3;
    curve1_h.Color = 'red';
% f(x) curve
curve2_h = plot(axes_h, x_vector, f([], x_vector, r_vector(1)));
    % Line Properties
    curve2_h.LineWidth = 2;
    curve2_h.Color = 'blue'; 
pause();
for i = 2 : length(r_vector)
    curve2_h.YData = f([], x_vector, r_vector(i));
    axes_h.Title.String = [f_string, '\qquad \qquad ($\omega = 1; a$ = ', num2str(r_vector(i)), ')'];
    drawnow();   
    pause()
end

function y = f(t, x, r)
%     y = 1 - r * sin(x);
    y = r + sin(x) + cos(2*x);
end