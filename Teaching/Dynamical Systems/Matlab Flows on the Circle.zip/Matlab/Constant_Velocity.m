%% Description
% This script shows an animation of a dynamical system evolving on 2 circles.

%% User Input:
% First, code the periodic function f(t,theta,r) for your dynamical system:
% dtheta/dt = f(t,theta,r), where 
%               - theta is the (two dimensional) state variable. The two
%               states evolve on a circle.
%               - t is time
%               - r is a vector that holds some parameters.
% The function is located at the bottom of this m-file.
% Then, specify the simulation parameters:
%               - r.
%               - dt is the discretization step for plotting the solutions.
%               - tf is the final time of simulation.
%               - IC is the initial condition.

%% Clear Workspace and Set Interpreter to Latex
close all;
clc;
clear;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Simulation Parameters
omega = 2 * pi/3;
dt = 0.075; tf = 8;            
t = 0 : dt : tf;      % Time Horizon
IC = pi/6; 
% theta_t = omega * t + IC;
theta_t = [omega * t + IC; -omega * t + IC];

%% Animation
Animate_Phases(t, theta_t, 1);


