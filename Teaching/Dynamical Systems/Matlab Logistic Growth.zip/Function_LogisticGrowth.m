function fx = Function_LogisticGrowth(t,x)
fx = x * (1 - x);
end

