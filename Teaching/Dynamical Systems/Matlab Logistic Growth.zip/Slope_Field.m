%% Clear Workspace
clear;
close all;
clc;

%% Creating a Grid
t_initial = 0;
t_final = 10;
dt = 0.2;
x_initial = 0;
x_final = 2;
dx = 0.2;
[t_mesh, x_mesh] = meshgrid(t_initial:dt:t_final, x_initial:dx:x_final);

%% Evaluating the Slopes at Each Point on the Grid
Slope_mesh = x_mesh .* (1 - x_mesh);

%% Constructing a Vector Field that has the Calculated Slopes with Fixed Lengths
Length = 0.1;
Vector_x = Length ./ sqrt(1 + Slope_mesh.^2);
Vector_y = Slope_mesh .* Vector_x;

%% Plotting the Slope Field
quiver(t_mesh, x_mesh, Vector_x, Vector_y, 'LineWidth', 0.75, 'Color', 'k');
axis([t_initial t_final x_initial x_final]);
xlabel('$t$', 'interpreter', 'latex', 'FontSize', 20);
ylabel('$x$', 'interpreter', 'latex', 'FontSize', 20);

%% Simulating the Dynamical System
Initial_Condition1 = 0;
Initial_Condition2 = 0.5;
Initial_Condition3 = 1;
Initial_Condition4 = 2;
[t1, x1] = ode45(@Function_LogisticGrowth, [0 10], Initial_Condition1);
[t2, x2] = ode45(@Function_LogisticGrowth, [0 10], Initial_Condition2);
[t3, x3] = ode45(@Function_LogisticGrowth, [0 10], Initial_Condition3);
[t4, x4] = ode45(@Function_LogisticGrowth, [0 10], Initial_Condition4);

%% Plotting the Solutions
hold on;
plot(t1, x1, 'LineWidth', 3);
plot(t2, x2, 'LineWidth', 3);
plot(t3, x3, 'LineWidth', 3);
plot(t4, x4, 'LineWidth', 3);
