%% Clear Workspace
close all;
clc;
clear;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Simulation Parameters
tf = 4000;

%% Initial Conditions
IC = [1e-2, 1e-8, 6e-7, 1e-10, 1e-10, 1e-10, 1e-13, 0, 1e-3, 0]';
% IC = [1e-2, 1e-9, 6e-4, 1e-6, 1e-6, 1e-7, 1e-9, 0, 1e-3, 0]';

%% Solving
Options = odeset('AbsTol', 1e-12, 'RelTol', 1e-12);
[t, x] = ode15s(@(t,x) BR_RHS(t, x), [0, tf], IC, Options);

%% Plotting
figure();
plot(t, log10(x), 'LineWidth', 2);
grid on;
axis([0 2000 -14 0]);
legend('$x_1$', '$x_2$', '$x_3$', '$x_4$', '$x_5$', '$x_6$', '$x_7$', '$x_8$', '$x_9$', '$x_{10}$');
xlabel('Time'); ylabel('$\log_{10}$(Concentration)');
set(gca, 'FontSize', 30);
figure();
subplot 121
plot(t, log10(x(:,2)), 'LineWidth', 2); hold on
plot(t, log10(x(:,3)), 'LineWidth', 2);
grid on;
axis([0 2000 -14 0]);
legend('[I$^-$]', '[I$_2$]');
xlabel('Time'); ylabel('$\log_{10}$(Concentration)');
set(gca, 'FontSize', 30);
subplot 122
plot(log10(x(:,2)), log10(x(:,3)), 'LineWidth', 2, 'Color', 'black'); hold on
grid on;
xlabel('$\log$[I$^-$]'); ylabel('$\log$[I$_2$]');
set(gca, 'FontSize', 30);

