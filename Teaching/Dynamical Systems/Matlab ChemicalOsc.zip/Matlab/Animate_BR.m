%% Clear Workspace
close all;
clear;
clc;
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% Simulation Parameters
tf = 4000;
dt = 0.1;
t = 0 : dt : tf;

%% Initial Conditions
IC = [1e-2, 1e-8, 6e-7, 1e-10, 1e-10, 1e-10, 1e-13, 0, 1e-3, 0]';
% IC = [1e-2, 1e-9, 6e-4, 1e-6, 1e-6, 1e-7, 1e-9, 0, 1e-3, 0]';

%% Solving
Options = odeset('AbsTol', 1e-12, 'RelTol', 1e-12);
[~, x] = ode15s(@(t,x) BR_RHS(t, x), t, IC, Options);
I2 = x(:,3);
I_ = x(:,2);

%% Animation
N_D = 60;
x_Down = downsample(log10(I_), N_D); y_Down = downsample(log10(I2), N_D);
t_Down = downsample(t, N_D);
figure();
axes1_h = subplot(1,2,1);
% Axis Properties
    hold(axes1_h, 'on');  
    axes1_h.XLim = [0, tf];
    axes1_h.YLim = [-11, -2];
    axes1_h.FontSize = 24;
    grid(axes1_h, 'on');
        % Axis Title Properties
        axes1_h.Title.String = 'Trajectories in Time';
        axes1_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes1_h.XLabel.String = '$t$';
        axes1_h.YLabel.String = '$\log$(Concentration)';
axes2_h = subplot(1,2,2);
% Axis Properties
    hold(axes2_h, 'on');  
    axes2_h.XLim = [-11, -5];
    axes2_h.YLim = [-7, -3];
    axes2_h.FontSize = 24;
    grid(axes2_h, 'on');
        % Axis Title Properties
        axes2_h.Title.String = 'Trajectories in Phase Plane';
        axes2_h.Title.FontSize = 30;
        % Axis Labels Properties
        axes2_h.XLabel.String = '$\log$[I$^-$]';
        axes2_h.YLabel.String = '$\log$[I$_2$]';
% Initialize Figure
plot(axes1_h, t_Down(1), x_Down(1), 'b', 'LineWidth', 2);
plot(axes1_h, t_Down(1), y_Down(1), 'r', 'LineWidth', 2);
legend(axes1_h, '$\log$[I$^-$]', '$\log$[I$_2$]', 'AutoUpdate','off');
Box_h1 = fill([-8, -11, -11, -8], [-5, -5, -3, -3], [0.9290, 0.6940, 0.1250]);
Box_h2 = fill([-8, -8, -5, -5], [-5, -3, -3, -5], 'blue');
Box_h1.FaceAlpha = 0.5; Box_h2.FaceAlpha = 0.5;
scatter_h = plot(axes2_h, x_Down(1), y_Down(1), 'ko', 'MarkerFaceColor', 'm', 'MarkerSize', 20);
plot(axes2_h, log10(I_), log10(I2), 'k', 'LineWidth', 2);
pause();
% Animate
for i = 2 : length(t_Down)
    plot(axes1_h, [t_Down(i-1) t_Down(i)], [x_Down(i-1) x_Down(i)], 'b', 'LineWidth', 2);
    plot(axes1_h, [t_Down(i-1) t_Down(i)], [y_Down(i-1) y_Down(i)], 'r', 'LineWidth', 2);
    scatter_h.XData = x_Down(i); scatter_h.YData = y_Down(i);
    drawnow();
end

