function dx = BR_RHS(t, x)
    %% Parameters
    %     X10 = 0.04; X30 = 2.5e-6; % Bistability
    X10 = 0.035; X30 = 1e-6; % Oscillations
    X20 = 0;
    X40 = 0;
    X50 = 0;
    X60 = 0;
    X70 = 0;
    X80 = 0;
    X90 = 0.0015;
    X100 = 0.33;
    h = 0.056;
    A = 0.004;
    k1 = 1.43e3;
    k2 = 2e10;
    k3 = 3.1e12;
    K3 = 2.2;
    k4 = 7.3e3;
    K4 = 1.7e7;
    k5 = 6e5;
    k6 = 1e4;
    k7 = 3.2e4;
    k8 = 7.5e5;
    k9 = 40;
    C9 = 1e4;
    k0 = 1 / 156;
    k10 = 37;
    %% Computing
    x1 = x(1); x2 = x(2); x3 = x(3); x4 = x(4); x5 = x(5);
    x6 = x(6); x7 = x(7); x8 = x(8); x9 = x(9); x10 = x(10);
    dx1 = -k1*h^2*x2*x1 - k4*h*x1*x4 + K4*x6^2 + k5*x4^2 + k0*(X10 - x1);
	dx2 = -k1*h^2*x2*x1 - k2*h*x4*x2 - k3*h*x5*x2 + K3*x3 + k9*x9*x3/(1 + C9*x3) + k10*x10*x5 + k0*(X20 - x2);
    dx3 = k3*h*x5*x2 - K3*x3 - k9*x9*x3/(1 + C9*x3) + k0*(X30 - x3);
    dx4 = k1*h^2*x2*x1 - k2*h*x4*x2 - k4*h*x1*x4 + K4*x6^2 - 2*k5*x4^2 + k6*x6*(A - x7) + k0*(X40 - x4);
	dx5 = k1*h^2*x2*x1 + 2*k2*h*x4*x2 - k3*h*x5*x2 + K3*x3 + k5*x4^2 - k10*x10*x5 + k0*(X50 - x5);
    dx6 = 2*k4*h*x1*x4 - 2*K4*x6^2 - k6*x6*(A - x7) + k0*(X60 - x6);
    dx7 = k6*x6*(A - x7) - k7*x7*x10 + k0*(X70 - x7);
    dx8 = k7*x7*x10 - 2*k8*x8^2 + k0*(X80 - x8);
    dx9 = -k9*x9*x3/(1 + C9*x3) + k0*(X90 - x9);
    dx10 = -k7*x7*x10 + k8*x8^2 - k10*x10*x5 + k0*(X100 - x10);
    dx = [dx1; dx2; dx3; dx4; dx5; dx6; dx7; dx8; dx9; dx10];
end

