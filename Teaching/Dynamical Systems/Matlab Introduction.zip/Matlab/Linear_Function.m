function [fx] = Linear_Function(t, x)
theta = -1;
fx = theta * x;
end

