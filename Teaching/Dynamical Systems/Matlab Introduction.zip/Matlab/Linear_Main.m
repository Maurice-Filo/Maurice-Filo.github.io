%% Clear Workspace
clear; clc; close all;

%% Setting the Initial Condition
x0 = 5;

%% Setting the Time Span
Time_Span = [0, 10];

%% Solving...
[t, x] = ode45(@Linear_Function, Time_Span, x0);

%% Plotting the Solution
plot(t, x, 'LineWidth', 3);

%% Prepairing and Saving the Figure
save_flag = 1;
scale = 4;
width = 7.5*scale;
height = 5*scale;
x0 = 10;
y0 = 5;
set(gcf, 'Units', 'centimeters', 'Position', [x0, y0, width, height], 'PaperPositionMode', 'auto');
AxesPosition = [0.1, 0.15, 0.85, 0.7];
FontSize = 7*scale; 
xmax = 10;
ymax = 7;
set(gca, 'Units', 'normalized', 'Position', AxesPosition);
axis(gca, [0, xmax, 0, ymax]);
set(gca, 'Units', 'normalized', 'XTick', linspace(0, xmax, 11), 'YTick', linspace(0, ymax, 8), ...
    'FontUnits', 'points', 'FontWeight', 'normal', 'FontSize', FontSize, 'FontName', 'Times');
xlabel(gca, 't', 'interpreter', 'latex'); 
ylabel(gca, '$x(t)$', 'interpreter', 'latex'); 
title(gca, 'Solution of $\dot x = -x; \quad x(0) = 5$', 'interpreter', 'latex');
grid on;
set(gcf, 'Color', 'white');
% Save as PDF
if(save_flag == 1)
    FileName = 'Linear1';
    h_figure = gcf;
    h_figure.PaperPositionMode = 'auto';
    fig_pos = h_figure.PaperPosition;
    h_figure.PaperSize = [fig_pos(3) fig_pos(4)];
    print(h_figure, FileName,'-dpdf', '-r1000');
end
