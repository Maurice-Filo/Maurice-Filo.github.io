function [fx] = Nonlinear_Function(t, x)
theta = 1;
fx = theta*x - x^3;
end
