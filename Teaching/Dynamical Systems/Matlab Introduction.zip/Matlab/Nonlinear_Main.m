%% Clear Workspace
clear; clc; close all;

%% Setting the Initial Condition
x0_1 = -0.1;
x0_2 = 0.1;
x0_3 = 0;

%% Setting the Time Span
Time_Span = [0, 10];

%% Solving...
[t1, x1] = ode45(@Nonlinear_Function, Time_Span, x0_1);
[t2, x2] = ode45(@Nonlinear_Function, Time_Span, x0_2);
[t3, x3] = ode45(@Nonlinear_Function, Time_Span, x0_3);


%% Plotting the Solution
plot(t1, x1, 'LineWidth', 3);
hold on;
plot(t2, x2, 'Linewidth', 3);
plot(t3, x3, 'Linewidth', 3, 'color', 'k');
leg = legend('$x(0) = -0.1$', '$x(0) = +0.1$', '$x(0) = 0$');
set(leg, 'interpreter', 'latex', 'Location', 'NorthWest');
%% Prepairing and Saving the Figure
save_flag = 1;
scale = 4;
width = 7.5*scale;
height = 5*scale;
x0 = 10;
y0 = 5;
set(gcf, 'Units', 'centimeters', 'Position', [x0, y0, width, height], 'PaperPositionMode', 'auto');
AxesPosition = [0.1, 0.15, 0.85, 0.7];
FontSize = 7*scale; 
xmax = 10;
ymax = 2;
set(gca, 'Units', 'normalized', 'Position', AxesPosition);
axis(gca, [0, xmax, -ymax, ymax]);
set(gca, 'Units', 'normalized', 'XTick', linspace(0, xmax, 11), 'YTick', linspace(-ymax, ymax, 5), ...
    'FontUnits', 'points', 'FontWeight', 'normal', 'FontSize', FontSize, 'FontName', 'Times');
xlabel(gca, 't', 'interpreter', 'latex'); 
ylabel(gca, '$x(t)$', 'interpreter', 'latex'); 
title(gca, 'Solution of $\dot x = x - x^3$ for various Initial Conditions', 'interpreter', 'latex');
grid on;
set(gcf, 'Color', 'white');
% Save as PDF
if(save_flag == 1)
    FileName = 'Nonlinear1';
    h_figure = gcf;
    h_figure.PaperPositionMode = 'auto';
    fig_pos = h_figure.PaperPosition;
    h_figure.PaperSize = [fig_pos(3) fig_pos(4)];
    print(h_figure, FileName,'-dpdf', '-r1000');
end
