function [fx] = HO_Function(t, x)
fx = [x(2); 5 * (1-x(1)^2) * x(2) - x(1)];
end
