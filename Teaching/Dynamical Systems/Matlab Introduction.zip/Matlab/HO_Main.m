%% Clear Workspace
clear; clc; close all;

%% Setting the Initial Condition
x0 = [3; 1];

%% Setting the Time Span
Time_Span = [0, 100];

%% Solving...
[t, x] = ode45(@HO_Function, Time_Span, x0);

%% Plotting the Solution
plot(t, x(:,1), 'LineWidth', 3);
hold on;
plot(t, x(:,2), 'Linewidth', 3);
leg = legend('$x_1(t)$', '$x_2(t)$');
set(leg, 'interpreter', 'latex');

%% Prepairing and Saving the Figure
save_flag = 1;
scale = 4;
width = 7.5*scale;
height = 5*scale;
x0 = 10;
y0 = 5;
set(gcf, 'Units', 'centimeters', 'Position', [x0, y0, width, height], 'PaperPositionMode', 'auto');
AxesPosition = [0.11, 0.15, 0.85, 0.7];
FontSize = 7*scale; 
xmax = 100;
ymax = 9;
set(gca, 'Units', 'normalized', 'Position', AxesPosition);
axis(gca, [0, xmax, -ymax, ymax]);
set(gca, 'Units', 'normalized', 'XTick', linspace(0, xmax, 11), 'YTick', linspace(-ymax, ymax, 5), ...
    'FontUnits', 'points', 'FontWeight', 'normal', 'FontSize', FontSize, 'FontName', 'Times');
xlabel(gca, 't', 'interpreter', 'latex'); 
ylabel(gca, '$x(t)$', 'interpreter', 'latex'); 
grid on;
set(gcf, 'Color', 'white');
% Save as PDF
if(save_flag == 1)
    FileName = 'HO1';
    h_figure = gcf;
    h_figure.PaperPositionMode = 'auto';
    fig_pos = h_figure.PaperPosition;
    h_figure.PaperSize = [fig_pos(3) fig_pos(4)];
    print(h_figure, FileName,'-dpdf', '-r1000');
end
