function [Solution, Y, x_vector, t_Pe, Pe1, Pe2, Pe, SimTime] = Simulate_ChirpTones_NonlinearCochlea(CochleaParameters, MiddleEarParameters, GainParameters, SpatialDiscretization, f0, f_Low, f_High, dB, Duration, Fs)
% This function simulates the ear model (middle ear + cochlea) with a chirp 
% tones input. The spatial discretization scheme for the macromechanical 
% and micromechanical stages are given as arguments to this function.
% Inputs:   
%           - CochleaParameters, MiddleEarParameters and GainParameters: 
%           structures that contain all the numerical values of the 
%           parameters of the cochlea, middle ear and active gain, 
%           respectively. These structures can be generated using the 
%           function Generate_EarParameters.
%           - SpatialDiscretization: structure that contains information
%           about the method used to realize the fluid mass operators and
%           the spatial discretization.
%                   + Method:   'FiniteDifference 1D'
%                               'FiniteDifference'
%                               'ChebyshevCollocation'
%                             	'Trapezoidal' 
%                               'Clenshaw-Curtis'
%                   + nx: number of nodes in the x-dimension.
%                   + ny: number of nodes in the y_dimension.
%                   + p: number of basis functions included.
%           - f0: fixed frequency of the first sound signal.
%           - f_Low and f_High: range of the chirp signal
%           - dB: dB level with respect to the threshold of hearing.
%           - Duration: Duration in seconds.
%           - Fs: Sampling Frequency
% Outputs: 
%           - Solution: Structure containing the solution of the differential equation.
%           - Y: Matrix that contains columns corresponding to the BM
%           response profile at all locations at each instant of time.
%           - x_vector: vector containing the spatial discretization.
%           - t_Pe and Pe: the time vector and pressure at the eardrum.
%           - Simtime: Time to execute this function.
Start = tic;
%% Loading the Parameters
Method = SpatialDiscretization.Method;
m1 = CochleaParameters.m1;
m2 = CochleaParameters.m2;
c1 = CochleaParameters.c1;
c2 = CochleaParameters.c2;
c3 = CochleaParameters.c3;
c4 = CochleaParameters.c4;
k1 = CochleaParameters.k1;
k2 = CochleaParameters.k2;
k3 = CochleaParameters.k3;
k4 = CochleaParameters.k4;
L = CochleaParameters.L;
mm = MiddleEarParameters.mm;
cm = MiddleEarParameters.cm;
km = MiddleEarParameters.km;
Pref = MiddleEarParameters.Pref;
lambda = GainParameters.lambda;
theta = GainParameters.theta;
Ref = GainParameters.Ref;
gamma0 = GainParameters.gamma0;
b = CochleaParameters.b;
g = CochleaParameters.g;

%% Constructing the Realizations of the Fluid Mass and Gaussian Weighing Operators
switch Method
    case 'FiniteDifference 1D'
        nx = SpatialDiscretization.nx;
        [Mf, Ms, x_vector] = MacroMechanical_Operators_FD_1D(nx, CochleaParameters);
        [G_lambda, ~] = GaussianWeighing_Operator(lambda, L, nx, 2, 0.01);
    case 'FiniteDifference 2D' 
        nx = SpatialDiscretization.nx;
        ny = SpatialDiscretization.ny;
        [Mf, Ms, x_vector] = MacroMechanical_Operators_FD(nx, ny, CochleaParameters);
        [G_lambda, ~] = GaussianWeighing_Operator(lambda, L, nx, 2, 0);
    case 'ChebyshevCollocation'
        nx = SpatialDiscretization.nx;
        ny = SpatialDiscretization.ny;
        [Mf, Ms, x_vector] = MacroMechanical_Operators_Chebyshev(nx, ny, CochleaParameters);
        [G_lambda, ~] = GaussianWeighing_Operator(lambda, L, nx, 3, 0);
        Mf(find(Mf<=0)) = 0; % Because the Chebyshev Collocation Method was not implemented accurately.
    case 'Trapezoidal'
        nx = SpatialDiscretization.nx;
        p = SpatialDiscretization.p;
        [Mf, Ms, x_vector] = MacroMechanical_Operators_Trapezoidal(nx, p, CochleaParameters);
        [G_lambda, ~] = GaussianWeighing_Operator(lambda, L, nx, 2, 0);
    case 'Clenshaw-Curtis'
        nx = SpatialDiscretization.nx;
        p = SpatialDiscretization.p;
        [Mf, Ms, x_vector] = MacroMechanical_Operators_ClenshawCurtis(nx, p, CochleaParameters);
        [G_lambda, ~] = GaussianWeighing_Operator(lambda, L, nx, 3, 0);
    otherwise
        error('Unidentified Method for solving the macromechanical stage: MacroMechanical should take a value of 1, 2, 3 or 4!');
end

%% Spatial Discretization
M1 = sparse(1:nx, 1:nx, m1(x_vector));
M2 = sparse(1:nx, 1:nx, m2(x_vector));
C1 = sparse(1:nx, 1:nx, c1(x_vector));
C2 = sparse(1:nx, 1:nx, c2(x_vector));
C3 = sparse(1:nx, 1:nx, c3(x_vector));
C4 = sparse(1:nx, 1:nx, c4(x_vector));
K1 = sparse(1:nx, 1:nx, k1(x_vector));
K2 = sparse(1:nx, 1:nx, k2(x_vector));
K3 = sparse(1:nx, 1:nx, k3(x_vector));
K4 = sparse(1:nx, 1:nx, k4(x_vector));
gamma0_vector = gamma0(x_vector);

%% Constructing the Descriptor State Space Matrices of the Cochlea and Transfer function of the Middle Ear
Middle_Ear = tf([1 0 0], [mm cm km]);  
A0 = [sparse(2*nx,2*nx), speye(2*nx); -(g/b)*(K1+K3), K3, ...
                                      -(g/b)*(C1+C3), C3; ...
                                     (g/b)*K3, -(K2+K3), (g/b)*C3, -(C2+C3)];
C0 = [(g/b)*K4, -K4, (g/b)*C4, -C4];
B0 = [sparse(2*nx,nx); speye(nx); sparse(nx,nx)];
B = [sparse(2*nx,1); -Ms; sparse(nx,1)];
C = [speye(nx), sparse(nx,3*nx)];
E = [speye(2*nx), sparse(2*nx,2*nx); sparse(2*nx,2*nx), [(g/b)*M1+Mf, sparse(nx,nx); sparse(nx,nx), M2]];

%% Constructing the Input 
% Duration = 0.01;            % Final Time
% f0 = 1000;
% f_Low = 1000;
% f_High = 1800;
% dB = 90;
dt = 1 / Fs;
t_Pe = 0 : dt : Duration; 
Pm = sqrt(2) * Pref * 10^(dB / 20); 
Pe1 = Pm * sin(2*pi*f0*t_Pe);
Pe2 = Pm * chirp(t_Pe, f_Low, Duration, f_High, 'linear', -90);
Pe = Pe1 + Pe2;
% sound(Pe, Fs);

%% Middle Ear Simulation
[s_Acceleration, ~] = lsim(Middle_Ear, Pe, t_Pe);

%% Inner Ear Simulation
Tspan = [0 Duration];  
IC = 0 * ones(4*nx,1);
Options = odeset('Mass', E);
Solution = ode45(@(t, X) Function_Cochlea(t, X, t_Pe, s_Acceleration, A0, B0, C0, B, G_lambda, theta, Ref, gamma0_vector, nx), Tspan, IC, Options);
X = deval(Solution, t_Pe);
Y = C * X;
SimTime = toc(Start);
end


function [dX] = Function_Cochlea(t, X, t_Pe, s_Acceleration, A0, B0, C0, B, G_lambda, theta, Ref, gamma0_vec, nx)
s_Acceleration = interp1(t_Pe, s_Acceleration, t); 
u_tilde = G_lambda * ((X(1:nx)/Ref).^2);
gamma_vector = gamma0_vec ./ (1 + theta * u_tilde);
A = A0 + B0*sparse(1:nx,1:nx,gamma_vector)*C0;
dX = A * X + B * s_Acceleration;
t
end

