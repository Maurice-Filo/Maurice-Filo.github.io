function [G_lambda, x] = GaussianWeighing_Operator(lambda, L, n, Method, ratio)
% This function computes a finite dimensional realization of a truncated Gaussian
% Weighing operator of the active gain function.
% Inputs: 
%           - lambda: Width of the Gaussian function [cm]
%           - L: Length of the BM [cm]
%           - n: number of nodes used to compute the integral
%           - Method: Method of integration
%               Method = 1 : First order approximation 
%               Method = 2 : Second order approximation (Trapezoidal)
%               Method = 3 : Clenshaw-Curtis quadrature approximation
%           - ratio: the ratio relative to the peak after which the kernel
%           is set to zero to maintain sparsity
% Outputs: 
%           - G_lambda: Finite dimensional realization of the Gaussian
%           Weighing Operator
%           - x: Nodes

Gauss_Kernel = @(x,s) exp(-(x-s).^2 / (2*lambda^2));
[F, x] = Fredholm_Matrix(Gauss_Kernel, n, 0, L, Method);
Normalize = F * ones(n,1);
Normalize = 1 ./ Normalize;
G_lambda = F;
peak = max(max(G_lambda));
Truncate = ratio * peak;
for i = 1 : n
    for j = 1 : n
        if(G_lambda(i,j) <= Truncate)
            G_lambda(i,j) = 0;
        end
    end
end
G_lambda = sparse(G_lambda);
end

