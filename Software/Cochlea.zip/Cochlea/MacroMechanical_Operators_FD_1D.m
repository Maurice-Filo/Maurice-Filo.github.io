function [Mf, Ms, x_vector] = MacroMechanical_Operators_FD_1D(nx, CochleaParameters)
% This function computes the finite realization of the Mass Operators (in
% 1D) that give the pressure at the BM due to a BM acceleration
% input u with a stapes acceleration s: P0 = -(Ms*s + Mf*u). 
% The computation is done via a second order finite difference method.
% u should be given at the finite difference grid.
% nx is the number of x-grid points.
Nx = nx - 2;
L = CochleaParameters.L;                                        
H = CochleaParameters.H;                                        
rho = CochleaParameters.rho;                                    
dx = L / (Nx+1);
x_vector = (0 : dx : L)';                         
A = sparse(2:Nx+2,1:Nx+1,1,Nx+2,Nx+2);
A = A + A' - 2*speye(Nx+2);
A(1,2) = 2;
A(Nx+2,Nx+1) = 0;
A(Nx+2,Nx+2) = 1;
Ix = speye(Nx+2);
Ix(Nx+2,Nx+2) = 0;
one_x = sparse(1,1,1,Nx+2,1);
Mf = -A \ Ix * (2*rho*dx^2 / H);
Ms = -A \ one_x * 4 * rho * dx;
end

