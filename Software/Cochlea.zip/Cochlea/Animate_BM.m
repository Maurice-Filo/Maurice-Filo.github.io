function [] = Animate_BM(BM_Displacement, Name, X_Vector, Start, Time_Vector, Wait, Vertical_Bound)
% This function shows graphically the behavior of the Basilar Membranes with time. The function takes as arguments the following:
%               - BM_Displacement: This an array where each column corresponds to the BM profile at each instant of time.
%               - Name: This is a string that contains the name of the model giving the BM profile.
%               - X_Vector: Spatially Discretized x-dimension [cm]
%               - Start: This is the time instance where the animation is desired to start. [s]
%               - Time_Vector: This is the time vector of the simulation [s]
%               - Wait: This is the time interval to wait between each plot [s]
%               - Vertical_Bound: This is the vertical bound (y-axis) of the graph

F = size(BM_Displacement, 2) - 1;
Index = find(Time_Vector >= Start, 1);

figure();
hPlot = plot(X_Vector, BM_Displacement(:, Index), 'LineWidth', 2); 
axis([0 X_Vector(end) -Vertical_Bound Vertical_Bound]);
xlabel('Distance from the Stapes, cm');
ylabel('BM Displacement, nm');
legend(Name);
title('Basilar Membrane Animation');

for i = Index + 1 : F
    set(hPlot, 'YData', BM_Displacement(:, i));  
    time = num2str(Time_Vector(i) * 10^3, '%.3f');
    title(strcat(time, ' ms'));
    drawnow;
    pause(Wait); 
end
end

