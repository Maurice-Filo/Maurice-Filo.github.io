function [F_Matrix, x] = Fredholm_Matrix(K, n, a, b, Method)
% This function computes the nxn-matrix approximation of the Fredholm operator
% defined by its kernel given as a function handle K.
% Suppose that the Fredholm operator is denoted by F, then:
%       F: u ------> F(u), such that
%                   [F(u)](x) = \int_a^b K(x,s)u(s)ds
% K is given as a function handle: K = @(x,s) ....
% Method = 1 : First order approximation 
% Method = 2 : Second order approximation (Trapezoidal)
% Method = 3 : Clenshaw-Curtis quadrature approximation
%
% The operation in finite space becomes: F_Matrix * u_vector
% where u_vector is the evaluation of u at the nodes (equally spaced grid
% for methods 1 and 2; Chebyshev nodes for method 3).

d = [a,b];
K_Matrix = zeros(n,n);
switch Method
    case 1     
        x = linspace(a, b, n)';
        dx = x(2) - x(1);
        for i = 1 : n
            for j = 1 : n
                K_Matrix(i,j) = K(x(i),x(j));
            end
        end
        F_Matrix = K_Matrix * dx;
    case 2
        x = linspace(a, b, n)';
        dx = x(2) - x(1);
        for i = 1 : n
            for j = 1 : n
            K_Matrix(i,j) = K(x(i),x(j));
            end
        end
        w = ones(n,1); w(1) = 1/2; w(n) = 1/2;
        F_Matrix = K_Matrix * diag(w) * dx;
    case 3
        [x, w] = chebpts(n, d);
        for i = 1 : n
            for j = 1 : n
                K_Matrix(i,j) = K(x(i),x(j));
            end
        end
        F_Matrix = K_Matrix * diag(w);
    otherwise 
        error('Method should be 1, 2 or 3');
end
end

