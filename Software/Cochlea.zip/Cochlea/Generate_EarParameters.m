function [CochleaParameters, MiddleEarParameters, GainParameters] = Generate_EarParameters()
% This function stores the parameters of the cochlear model, the middle
% ear model and the active gain model in the three structures:
% CochleaParameters, MiddleEarParameters and GainParameters only.

% %% Stephen Elliot's Parameters for the Human Cochlea
% % Constants Parameters
% Pref = 20e-6;                               % [N.m^-2] RMS Sound Pressure Level at the Threshold of Hearing 
% mm = 2.96e-2;                                % [kg.m^-2] Mass of the Middle Ear 
% cm = 2.8e4;                                   % [N.s.m^-3] Damping Ratio of the Middle Ear
% km = 2.63e8;                                % [N.m^-3] Stiffness of the Middle Ear
% L = 0.035;                                    % [m] Basilar Membrane Length
% H = 0.001;                                    % [m] Basilar Membrane Height
% rho = 1000;                                  % [kg.m^-3] Fluid Density
% b = 0.4;
% g = 1;
% 
% % Variable Parameters along the Cochlear Partition 
% xs = 0.00375;
% m1 = @(x) 1.35 * 10^-2 * ones(length(x),1);                    % [kg.m^-2] Mass/Area of the Basilar Membrane
% m2 = @(x) 2.3 * 10^-3 * ones(length(x),1);                  % [kg.m^-2] Mass/Area of the Tectorial Membrane
% c1 = @(x) 1 + 19700 * exp(-179*(x+xs)); 
% c2 = @(x) 113 * exp(-176*(x+xs));
% c3 = @(x) 22.5 * exp(-64*(x+xs));
% c4 = @(x) 9650 * exp(-164*(x+xs));
% k1 = @(x) 4.95e9 * exp(-320*(x+xs));
% k2 = @(x) 3.15e7 * exp(-352*(x+xs));
% k3 = @(x) 4.5e7 * exp(-320*(x+xs));
% k4 = @(x) 2.82e9 * exp(-320*(x+xs));    
% 
% % Active Gain Parameters
% lambda = 0.08e-2;                              % [m] Critical Bandwidth on the Basilar Membrane
% theta = 0.5;                                % [Unitless] Nonlinear Coupling
% Ref = 1e-9;                                 % [m] Basilar Membrane Displacement Reference
% gamma0 = @(x) (tanh(x*100) + 8) / (tanh(L*100) + 8);
% gamma0 = @(x) 1 * ones(length(x),1);
% x_p = 1.82e-2;
% gamma_max = 1.03;
% epsilon = 0.06;
% gamma0 = @(x) gamma_max - epsilon + epsilon*heaviside(x-x_p);
% gamma0 = @(x) gamma_max - epsilon*heaviside(x-x_p);
% % Creating the Structures
% CochleaParameters.L = L;
% CochleaParameters.H = H;
% CochleaParameters.rho = rho;
% CochleaParameters.m1 = m1;
% CochleaParameters.m2 = m2;
% CochleaParameters.c1 = c1;
% CochleaParameters.c2 = c2;
% CochleaParameters.c3 = c3;
% CochleaParameters.c4 = c4;
% CochleaParameters.k1 = k1;
% CochleaParameters.k2 = k2;
% CochleaParameters.k3 = k3;
% CochleaParameters.k4 = k4;
% MiddleEarParameters.mm = mm;
% MiddleEarParameters.cm = cm;
% MiddleEarParameters.km = km;
% MiddleEarParameters.Pref = Pref;
% GainParameters.lambda = lambda;
% GainParameters.theta = theta;
% GainParameters.Ref = Ref;
% GainParameters.gamma0 = gamma0;
% CochleaParameters.b = b;
% CochleaParameters.g = g;


%% Stephen Elliot's Parameters for the Human Cochlea, Second set
%% Constants Parameters
Pref = 20e-6;                               % [N.m^-2] RMS Sound Pressure Level at the Threshold of Hearing 
mm = 2.96e-2;                                % [kg.m^-2] Mass of the Middle Ear 
cm = 2.8e4;                                   % [N.s.m^-3] Damping Ratio of the Middle Ear
km = 2.63e8;                                % [N.m^-3] Stiffness of the Middle Ear
L = 0.035;                                    % [m] Basilar Membrane Length
H = 0.001;                                    % [m] Basilar Membrane Height
rho = 1000;                                  % [kg.m^-3] Fluid Density
b = 0.4;
g = 1;

%% Variable Parameters along the Cochlear Partition 
xs = 0.00373;
m1 = @(x) 4.5 * 10^-3 * ones(length(x),1);                    % [kg.m^-2] Mass/Area of the Basilar Membrane
m2 = @(x) 7.2e-4 + 2.87*x*1e-2;                  % [kg.m^-2] Mass/Area of the Tectorial Membrane
c1 = @(x) 9 + 9990 * exp(-153*(x+xs)); 
c2 = @(x) 30 * exp(-171*(x+xs));
c3 = @(x) 6.6 * exp(-59.3*(x+xs));
c4 = @(x) 3300 * exp(-144*(x+xs));
k1 = @(x) 1.65e9 * exp(-279*(x+xs));
k2 = @(x) 1.05e7 * exp(-307*(x+xs));
k3 = @(x) 1.5e7 * exp(-279*(x+xs));
k4 = @(x) 9.23e8 * exp(-279*(x+xs));    

%% Active Gain Parameters
lambda = 0.89e-3;                              % [m] Critical Bandwidth on the Basilar Membrane 
theta = 10;                                % [Unitless] Nonlinear Coupling
Ref = 1e-9;                                 % [m] Basilar Membrane Displacement Reference
% rng('default');
gamma0 = @(x) 1 * ones(length(x),1);
% aa = 100; bb = 2;
% gamma0 = @(x) (tanh(aa*x) + bb) / (tanh(aa*L) + bb);
% x_p = 2e-2;
% gamma_max = 1;
% epsilon = 0.3;
% gamma0 = @(x) gamma_max - epsilon*heaviside(x-x_p);

%% Creating the Structures
CochleaParameters.L = L;
CochleaParameters.H = H;
CochleaParameters.rho = rho;
CochleaParameters.m1 = m1;
CochleaParameters.m2 = m2;
CochleaParameters.c1 = c1;
CochleaParameters.c2 = c2;
CochleaParameters.c3 = c3;
CochleaParameters.c4 = c4;
CochleaParameters.k1 = k1;
CochleaParameters.k2 = k2;
CochleaParameters.k3 = k3;
CochleaParameters.k4 = k4;
MiddleEarParameters.mm = mm;
MiddleEarParameters.cm = cm;
MiddleEarParameters.km = km;
MiddleEarParameters.Pref = Pref;
GainParameters.lambda = lambda;
GainParameters.theta = theta;
GainParameters.Ref = Ref;
GainParameters.gamma0 = gamma0;
CochleaParameters.b = b;
CochleaParameters.g = g;




% % Lamar Parameters
% Constant Parameters
% Pref = 20e-5;                               % [Ba] RMS Sound Pressure Level at the Threshold of Hearing 
% mm = 6.7e-3;                                % [g.cm^-2] Mass of the Middle Ear 
% cm = 236;                                   % [dyn.s.cm^-3] Damping Ratio of the Middle Ear
% km = 4.23e6;                                % [dyn.cm^-3] Stiffness of the Middle Ear
% L = 2.5;                                    % [cm] Basilar Membrane Length
% H = 0.1;                                    % [cm] Basilar Membrane Height
% rho = 0.1;                                  % [g.cm^-3]
% 
% Variable Parameters along the Cochlear Partition 
% m1 = @(x) 3 * 10^-3 * ones(length(x),1);                    % [g.cm^-2] Mass/Area of the Basilar Membrane
% m2 = @(x) 0.5 * 10^-3 * ones(length(x),1);                  % [g.cm^-2] Mass/Area of the Tectorial Membrane
% c1 = @(x) (20 + 1500 * exp(-2*x)) * 2 .* exp(-0.2773*x); 
% c2 = @(x) (10 * exp(-2.2*x)) * 2 .* exp(-0.2773*x);
% c3 = @(x) (2 * exp(-0.8*x)) * 2 .* exp(-0.2773*x);
% c4 = @(x) (1040 * exp(-2*x)) * 2 .* exp(-0.2773*x);
% k1 = @(x) 1.1e9 * exp(-4*x);
% k2 = @(x) 7e6 * exp(-4.4*x);
% k3 = @(x) 1e7 * exp(-4*x);
% k4 = @(x) 6.15e8 * exp(-4*x);    
% b = 1; 
% g = 1;
% 
% Active Gain Parameters
% lambda = 0.08;                              % [cm] Critical Bandwidth on the Basilar Membrane 
% theta = 0.5;                                % [Unitless] Nonlinear Coupling 
% Ref = 1e-7;                                 % [cm] Basilar Membrane Displacement Reference
% gamma0 = @(x) 1 * ones(length(x),1);
% x_p = 0.025;
% gamma_max = 1;
% epsilon = 0.1;
% gamma0 = @(x) gamma_max - epsilon + epsilon*heaviside(x-x_p);
% 
% Creating the Structures
% CochleaParameters.L = L;
% CochleaParameters.H = H;
% CochleaParameters.rho = rho;
% CochleaParameters.m1 = m1;
% CochleaParameters.m2 = m2;
% CochleaParameters.c1 = c1;
% CochleaParameters.c2 = c2;
% CochleaParameters.c3 = c3;
% CochleaParameters.c4 = c4;
% CochleaParameters.k1 = k1;
% CochleaParameters.k2 = k2;
% CochleaParameters.k3 = k3;
% CochleaParameters.k4 = k4;
% MiddleEarParameters.mm = mm;
% MiddleEarParameters.cm = cm;
% MiddleEarParameters.km = km;
% MiddleEarParameters.Pref = Pref;
% GainParameters.lambda = lambda;
% GainParameters.theta = theta;
% GainParameters.Ref = Ref;
% GainParameters.gamma0 = gamma0;
% CochleaParameters.b = b;
% CochleaParameters.g = g;

% %%% Neely and Kim Parameters
% %% Constant Parameters
% Pref = 20e-5;                               % [N.m^-2] RMS Sound Pressure Level at the Threshold of Hearing 
% mm = 45e-3;                                % [kg.m^-2] Mass of the Middle Ear 
% cm = 400;                                   % [N.s.m^-3] Damping Ratio of the Middle Ear
% km = 2.1e5;                                % [N.m^-3] Stiffness of the Middle Ear
% L = 2.5;                                    % [m] Basilar Membrane Length
% H = 0.1;                                    % [m] Basilar Membrane Height
% rho = 1;                                  % [kg.m^-3] Fluid Density
% As = 1e-2;                              % [m^2] Area of the Stapes Footplate
% Am = 0.35;                           % [m^2] Effective Area of the Ear Drum
% Gm = 0.5;                               % [Unitless] Lever Gain of the Middle Ear
% b = 0.4;
% g = 1;
% 
% %% Variable Parameters along the Cochlear Partition 
% m1 = @(x) 3 * 10^-3 * ones(length(x),1);                    % [g.cm^-2] Mass/Area of the Basilar Membrane
% m2 = @(x) 5 * 10^-4 * ones(length(x),1);                  % [g.cm^-2] Mass/Area of the Tectorial Membrane
% c1 = @(x) (20 + 1500 * exp(-2*x)); 
% c2 = @(x) (10 * exp(-2.2*x));
% c3 = @(x) (2 * exp(-0.8*x));
% c4 = @(x) (1040 * exp(-2*x));
% k1 = @(x) 1.1e9 * exp(-4*x);
% k2 = @(x) 7e6 * exp(-4.4*x);
% k3 = @(x) 1e7 * exp(-4*x);
% k4 = @(x) 6.15e8 * exp(-4*x);      
% 
% %% Active Gain Parameters
% lambda = 0.08;                              % [cm] Critical Bandwidth on the Basilar Membrane
% theta = 0.5;                                % [Unitless] Nonlinear Coupling
% Ref = 1e-7;                                 % [cm] Basilar Membrane Displacement Reference
% gamma0 = @(x) 1 * ones(length(x),1);
% % x_p = 0.025;
% % gamma_max = 1;
% % epsilon = 0.1;
% % gamma0 = @(x) gamma_max - epsilon + epsilon*heaviside(x-x_p);
% 
% %% Creating the Structures
% CochleaParameters.L = L;
% CochleaParameters.H = H;
% CochleaParameters.rho = rho;
% CochleaParameters.m1 = m1;
% CochleaParameters.m2 = m2;
% CochleaParameters.c1 = c1;
% CochleaParameters.c2 = c2;
% CochleaParameters.c3 = c3;
% CochleaParameters.c4 = c4;
% CochleaParameters.k1 = k1;
% CochleaParameters.k2 = k2;
% CochleaParameters.k3 = k3;
% CochleaParameters.k4 = k4;
% CochleaParameters.g = g;
% CochleaParameters.b = b;
% MiddleEarParameters.mm = mm;
% MiddleEarParameters.cm = cm;
% MiddleEarParameters.km = km;
% MiddleEarParameters.Pref = Pref;
% MiddleEarParameters.Am = Am;
% MiddleEarParameters.As = As;
% MiddleEarParameters.Gm = Gm;
% GainParameters.lambda = lambda;
% GainParameters.theta = theta;
% GainParameters.Ref = Ref;
% GainParameters.gamma0 = gamma0;


% %%% Stephen Elliot Parameters
% %% Constant Parameters
% Pref = 20e-6;                               % [N.m^-2] RMS Sound Pressure Level at the Threshold of Hearing 
% mm = 45e-2;                                % [kg.m^-2] Mass of the Middle Ear 
% cm = 4000;                                   % [N.s.m^-3] Damping Ratio of the Middle Ear
% km = 2.1e6;                                % [N.m^-3] Stiffness of the Middle Ear
% L = 2.5e-2;                                    % [m] Basilar Membrane Length
% H = 0.002;                                    % [m] Basilar Membrane Height
% rho = 1000;                                  % [kg.m^-3] Fluid Density
% b = 0.4;
% g = 1;
% 
% %% Variable Parameters along the Cochlear Partition 
% m1 = @(x) 3 * 10^-2 * ones(length(x),1);                    % [g.cm^-2] Mass/Area of the Basilar Membrane
% m2 = @(x) 5 * 10^-3 * ones(length(x),1);                  % [g.cm^-2] Mass/Area of the Tectorial Membrane
% c1 = @(x) (200 + 15000 * exp(-200*x)); 
% c2 = @(x) (100 * exp(-220*x));
% c3 = @(x) (20 * exp(-80*x));
% c4 = @(x) (10400 * exp(-200*x));
% k1 = @(x) 1.1e10 * exp(-400*x);
% k2 = @(x) 7e7 * exp(-440*x);
% k3 = @(x) 1e8 * exp(-400*x);
% k4 = @(x) 6.15e9 * exp(-400*x);      
% 
% %% Active Gain Parameters
% lambda = 0.08;                              % [cm] Critical Bandwidth on the Basilar Membrane
% theta = 0.5;                                % [Unitless] Nonlinear Coupling
% Ref = 1e-9;                                 % [cm] Basilar Membrane Displacement Reference
% gamma0 = @(x) 1 * ones(length(x),1);
% % x_p = 0.025;
% % gamma_max = 1;
% % epsilon = 0.1;
% % gamma0 = @(x) gamma_max - epsilon + epsilon*heaviside(x-x_p);
% 
% %% Creating the Structures
% CochleaParameters.L = L;
% CochleaParameters.H = H;
% CochleaParameters.rho = rho;
% CochleaParameters.m1 = m1;
% CochleaParameters.m2 = m2;
% CochleaParameters.c1 = c1;
% CochleaParameters.c2 = c2;
% CochleaParameters.c3 = c3;
% CochleaParameters.c4 = c4;
% CochleaParameters.k1 = k1;
% CochleaParameters.k2 = k2;
% CochleaParameters.k3 = k3;
% CochleaParameters.k4 = k4;
% CochleaParameters.g = g;
% CochleaParameters.b = b;
% MiddleEarParameters.mm = mm;
% MiddleEarParameters.cm = cm;
% MiddleEarParameters.km = km;
% MiddleEarParameters.Pref = Pref;
% GainParameters.lambda = lambda;
% GainParameters.theta = theta;
% GainParameters.Ref = Ref;
% GainParameters.gamma0 = gamma0;


end

