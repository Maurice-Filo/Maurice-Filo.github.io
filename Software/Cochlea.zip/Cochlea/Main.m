%% Clear Workspace
close all
clear
clc

%% Stimulus Frequencies, Amplitude & Duration
Duration = 0.03;         
f0 = 1000;
f_Low = 1000;
f_High = 1800;
dB = 90;

%% Cochlear Model Parameters
[CochleaParameters, MiddleEarParameters, GainParameters] = Generate_EarParameters();

%% Spatial Discretization Method
SpatialDiscretization.Method = 'FiniteDifference 1D';
SpatialDiscretization.nx = 400;

%% Simulation
Fs = 1e5;
[~, Y, x_vector, t_Pe, Pe1, Pe2, Pe, SimTime] = Simulate_ChirpTones_NonlinearCochlea(CochleaParameters, MiddleEarParameters, GainParameters, SpatialDiscretization, f0, f_Low, f_High, dB, Duration, Fs);

%% Animate
Animate_BM(Y, 'BM Displacement', x_vector, 0, t_Pe, 0, max(max(Y)));