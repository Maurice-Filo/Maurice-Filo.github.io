function Matrix = CreateStoichiometryFile(PlantCoefficients_Reactants, PlantCoefficients_Products, ...
                                          ControllerCoefficients_Reactants, ControllerCoefficients_Products, ...
                                          PlantSpeciesNames, ControllerSpeciesNames, ...
                                          PlantPropensities, ControllerPropensities, ...
                                          FilePath, NetworkName)
%% Construct Stoichiometry Matrix
Matrix = [PlantCoefficients_Products - PlantCoefficients_Reactants, ControllerCoefficients_Products - ControllerCoefficients_Reactants];

%% Construct Species 
Species = [PlantSpeciesNames, ControllerSpeciesNames];

%% Construct Propensities
Propensities = [PlantPropensities, ControllerPropensities];

%% Create and Open m-file
fid = fopen([FilePath, '/', 'StoichiometryMatrix_' NetworkName, '.m'],'wt');

%% Write Function Declaration Syntax
fprintf(fid, ['function S = StoichiometryMatrix_', NetworkName, '()\n']);

%% Write Comments
% Introductory Line
fprintf(fid, ['%% Stoichiometry Matrix for Network ', NetworkName, '\n']);
% Species
fprintf(fid, '%% \t Species: \t\t X = [');
for i = 1 : length(Species)
    if i < length(Species)
        fprintf(fid, [Species{i}, '; ']);
    else
        fprintf(fid, [Species{i}, ']\n']);
    end
end
% Reactions
fprintf(fid, '%% \t Reactions: \t');
for i = 1 : size(PlantCoefficients_Reactants,2)
    if i == 1
        fprintf(fid, ['R', num2str(i), ':\t\t']);
    else
        fprintf(fid, ['%% \t\t\t\t    R', num2str(i), ':\t\t']);
    end
    [Reactants_Text, Products_Text] = Coeff2Rxn(PlantCoefficients_Reactants(:,i), PlantCoefficients_Products(:,i), Species);
    fprintf(fid, [Reactants_Text, '\t\t\t\t\t--> \t', Products_Text, '\t\t\t\t[', Propensities{i}, ']\n']);
end
for i =  1 : size(ControllerCoefficients_Reactants,2)
    fprintf(fid, ['%% \t\t\t\t    R', num2str(size(PlantCoefficients_Reactants,2) + i), ':\t\t']);
    [Reactants_Text, Products_Text] = Coeff2Rxn(ControllerCoefficients_Reactants(:,i), ControllerCoefficients_Products(:,i), Species);
    fprintf(fid, [Reactants_Text, '\t\t\t\t\t--> \t', Products_Text, '\t\t\t\t[', Propensities{size(PlantCoefficients_Reactants,2) + i}, ']\n']);
end

%% Write Matrix
fprintf(fid, 'S = [\t');
for i = 1 : size(Matrix, 1)
    if i > 1
        fprintf(fid, '\t\t');
    end
    for j = 1 : size(Matrix, 2)
        if j < size(Matrix, 2)
            fprintf(fid, [num2str(Matrix(i,j)), ',\t\t']);
        else
            fprintf(fid, num2str(Matrix(i,j)));
        end
    end
    if i < size(Matrix, 1)
        fprintf(fid, ['; ...', '\n']);
    else
        fprintf(fid, '\t];\n');
    end
end

%% Write End of Function
fprintf(fid, 'end');

%% Close File
fclose(fid);

end

