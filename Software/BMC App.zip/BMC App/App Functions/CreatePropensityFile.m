function Handle_Function = CreatePropensityFile(PlantCoefficients_Reactants, PlantCoefficients_Products, ...
                                                ControllerCoefficients_Reactants, ControllerCoefficients_Products, ...
                                                PlantSpeciesNames, ControllerSpeciesNames, ...
                                                PlantPropensities, ControllerPropensities, ...
                                                PlantParameters, ControllerParameters, ...
                                                FilePath, NetworkName)
%% Construct Species 
Species = [PlantSpeciesNames, ControllerSpeciesNames];

%% Construct Propensities
Propensities = [PlantPropensities, ControllerPropensities];

%% Construct Parameters
Parameters = [PlantParameters, ControllerParameters];

%% Create and Open m-file
fid = fopen([FilePath, '/', 'PropensityFunction_' NetworkName, '.m'],'wt');

%% Write Function Declaration Syntax
fprintf(fid, ['function a = PropensityFunction_', NetworkName, '(x, Parameters)\n']);

%% Write Comments
% Introductory Line
fprintf(fid, ['%% Propensity for Network ', NetworkName, '\n']);
% Species
fprintf(fid, '%% \t Species: \t\t X = [');
for i = 1 : length(Species)
    if i < length(Species)
        fprintf(fid, [Species{i}, '; ']);
    else
        fprintf(fid, [Species{i}, ']\n']);
    end
end
% Reactions
fprintf(fid, '%% \t Reactions: \t');
for i = 1 : size(PlantCoefficients_Reactants,2)
    if i == 1
        fprintf(fid, ['R', num2str(i), ':\t\t']);
    else
        fprintf(fid, ['%% \t\t\t\t    R', num2str(i), ':\t\t']);
    end
    [Reactants_Text, Products_Text] = Coeff2Rxn(PlantCoefficients_Reactants(:,i), PlantCoefficients_Products(:,i), Species);
    fprintf(fid, [Reactants_Text, '\t\t\t\t\t--> \t', Products_Text, '\t\t\t\t[', Propensities{i}, ']\n']);
end
for i =  1 : size(ControllerCoefficients_Reactants,2)
    fprintf(fid, ['%% \t\t\t\t    R', num2str(size(PlantCoefficients_Reactants,2) + i), ':\t\t']);
    [Reactants_Text, Products_Text] = Coeff2Rxn(ControllerCoefficients_Reactants(:,i), ControllerCoefficients_Products(:,i), Species);
    fprintf(fid, [Reactants_Text, '\t\t\t\t\t--> \t', Products_Text, '\t\t\t\t[', Propensities{size(PlantCoefficients_Reactants,2) + i}, ']\n']);
end
fprintf(fid, '\n');

%% Extract Parameters
fprintf(fid, '%%%% Extract Parameters\n');
for i = 1 : length(Parameters)
    fprintf(fid, [Parameters{i}, ' = Parameters.', Parameters{i}, ';\n']);
end
fprintf(fid, '\n');

%% Extract State Variables
fprintf(fid, '%%%% Extract State Variables\n');
for i = 1 : length(Species)
    fprintf(fid, [Species{i}, ' = x(', num2str(i), ');\n']);
end
fprintf(fid, '\n');

%% Write Propensities
fprintf(fid, '%%%% Propensities\n');
fprintf(fid, 'a = [ ...\n');
for i = 1 : length(Propensities)
    if (i < length(Propensities))
        fprintf(fid, ['\t\t', Propensities{i}, '; ...\n']);
    end
    if i == length(Propensities)
        fprintf(fid, ['\t\t', Propensities{i}, ' ...\n']);
    end
end
fprintf(fid, '\t];\n');

%% Write End of Function
fprintf(fid, 'end');

%% Close File
fclose(fid);

%% Return Handle
Handle_Function = [];
eval(['Handle_Function = @PropensityFunction_', NetworkName, ';']); 

end

