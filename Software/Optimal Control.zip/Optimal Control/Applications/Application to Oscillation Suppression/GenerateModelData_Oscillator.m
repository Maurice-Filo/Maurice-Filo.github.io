function [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Oscillator()
% This function generates necessary data for the nonlinear oscillator model
% (with nonlinear damping coefficient).

%% Time Discretization Parameters
tf = 40;
Nt = 1000;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Initial Conditions
x0 = [0.05 0]';

%% Performance Index Parameters
Q = [1,0; 0,1];
R = 0.01;

%% Parameters
m = 1; c = 0.5; k = 10; 
gamma0 = 1; theta = 0.5;
f_Parameters.A0 = [0, 1; -k/m, -c/m];
f_Parameters.gamma_m = @(y) (gamma0 / m) / (1 + theta * y^2);
f_Parameters.dgamma_m = @(y) -(gamma0*2*theta*y / m) / (1 + theta * y^2)^2;
f_Parameters.B = [0; 1];
f_Parameters.C = [1 0];
end

