function  f = f_Oscillator(~, x, u, f_Parameters)
A0 = f_Parameters.A0;
B = f_Parameters.B;
C = f_Parameters.C;
gamma_m = f_Parameters.gamma_m;
y = C * x;
A = A0 + [0, 0; 0, gamma_m(y)];
f = A * x + B * u;
end

