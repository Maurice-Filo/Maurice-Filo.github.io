function [A_k, B_k] = fJacobians_Oscillator(x_k, ~, ~, f_Parameters)
A0 = f_Parameters.A0;
B = f_Parameters.B;
gamma_m = f_Parameters.gamma_m;
dgamma_m = f_Parameters.dgamma_m;
A_k = A0 + [0, 0; x_k(2)*dgamma_m(x_k(1)), gamma_m(x_k(1))];
B_k = B;
end

