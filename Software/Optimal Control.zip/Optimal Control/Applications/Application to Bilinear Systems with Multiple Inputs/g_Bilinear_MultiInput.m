function [g] = g_Bilinear_MultiInput(x, g_Parameters)
P = g_Parameters.P;
g = sum(x .* (P * x));
end

