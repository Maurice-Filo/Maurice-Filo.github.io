function  f = f_Bilinear_MultiInput(~, x, u, f_Parameters)
% This function calculates f(x, u) = (A + B1*u1 + B2*u2 + ... + Bn*un)*x where:
%           A = f_Parameters.A
%           B = f_Parameters.B
A = f_Parameters.A;
B = f_Parameters.B;
Nu = size(B,3);
Nx = size(A,1);
f = zeros(Nx,1);
for i = 1 : Nu
    f = f + u(i) * B(:,:,i) * x;
end
f = f + A*x;
end

