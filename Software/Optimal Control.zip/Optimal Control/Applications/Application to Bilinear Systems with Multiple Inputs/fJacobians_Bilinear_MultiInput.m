function [A_k, B_k] = fJacobians_Bilinear_MultiInput(x_k, u_k, ~, f_Parameters)
% This function computes the partial derivatives of f(x,u) with respect to x and
% u for the bilinear systems evaluated at (x_k,u_k,t), that is
%       A_k = \frac{\partial}{\partial x} f(x_k,u_k)
%       B_k = \frac{\partial}{\partial x} f(x_k,u_k)
A = f_Parameters.A;
B = f_Parameters.B;
Nx = size(A,1);
Nu = size(B,3);
A_k = zeros(Nx,Nx);
B_k = zeros(Nx,Nu);
for i = 1 : Nu
A_k = A_k + B(:,:,i) * u_k(i);
B_k(:,i) = B(:,:,i) * x_k;
end
A_k = A_k + A;
end

