function [f_Parameters, t_vector, x0, Q, R, g_Parameters] = GenerateModelData_Bilinear_MultiInput()
% Starting from the Hamiltonians H0, H1, H2, ..., Hn (to be specified), this function 
% generates the A and Bi matrices of the bilinear system of the form:
%                       dx = (A + B1*u1 + B2*u2 + ... + Bn*un)*x
% The matrices A and Bi's are stored as follows:   f_Parameters.A = A 
%                                                  f_Parameters.B(:,:,i) = Bi
% The time horizon with the initial condition are returned as t_vector and
% x0, respsectively.

%% Time Discretization Parameters
tf = 10 * pi;
Nt = 500;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Bilinear Model Parameters
H0 = [0 0; 0 1];
H1 = [0 1; 1 0];
N = size(H0,1);
A = [zeros(N,N) H0; -H0 zeros(N,N)];
B(:,:,1) = [zeros(N,N) H1; -H1 zeros(N,N)];
B(:,:,2) = [H1 zeros(N,N); zeros(N,N) H1];
n = size(B,3);

%% Initial Conditions
x0 = [1 0 0 0]';
f_Parameters.A = A;
f_Parameters.B = B;

%% Performance Index Parameters
epsilon = 0.01;
Q_bar = [1 0; 0 epsilon];
Q = [Q_bar zeros(N,N); zeros(N,N) Q_bar];
R = eye(n);

%% Stabilizing Gain Function Parameters;
P = H1*H0 - H0*H1;
g_Parameters.P = [P, zeros(N,N); zeros(N,N), P];
end

