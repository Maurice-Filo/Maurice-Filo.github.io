%% Plotting Results for the Unconstrained Gradient Descent Method
figure();
suptitle('LTI');
subplot 221
plot(t_vector, u_0, 'k', 'linewidth', 2);
hold on
plot(t_vector, u, 'b', 'linewidth', 2);
xlabel('t');
ylabel('u(t)');
legend('Initial Guess', 'Optimal Control');

subplot 222
plot(t_vector, x);
shading interp;
xlabel('t');
ylabel('x');
zlabel('Temperature');

subplot 223;
plot(J, 'x-');
xlabel('Iteration Number');
ylabel('J');

subplot 224;
plot(Step_History, 'kx-');
xlabel('Iteration Number');
ylabel('Step Size');
