function [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_LTI()
% This function generates the A and B matrices of the linear system of the form:
%                       dx = Ax + Bu
% The matrices A and B are stored as follows:   f_Parameters.A = A 
%                                               f_Parameters.B = B
% u as a control input and v is a fixed (uncontrollable) input. 
% The time horizon with the initial condition are returned as t_vector and
% x0, respsectively.

%% Time Discretization Parameters
tf = 5;
Nt = 1000;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Linear Model Parameters
% load System_LTI
% N = size(A,1);
N = 3;
A = [2 0 0; 0 -2 0; 0 0 -3];
B = [0.1; 0.2; -0.1];

%% Initial Conditions
x0 = [1 -1 2]';

%% Performance Index Parameters
Q = 1*eye(N);
R = 1;

f_Parameters.A = A;
f_Parameters.B = B;
end

