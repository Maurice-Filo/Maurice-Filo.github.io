function [Hxx, Hux, Hxu, Huu] = fHessians_LTI(~, ~, ~, ~)
% This function computes the partial second derivatives of f(x,u) with respect to x and
% u for the linear systems evaluated at (x_k,u_k,t), that is
%       Hxx = \frac{\partial^2}{\partial _{xx}} f(x_k,u_k)
%       Hux = \frac{\partial^2}{\partial _{xux}} f(x_k,u_k)
%       Hxu = \frac{\partial^2}{\partial _{xu}} f(x_k,u_k)
%       Huu = \frac{\partial^2}{\partial _{uu}} f(x_k,u_k)
% Note that in general these are 3D Matrices
A = f_Parameters.A;
B = f_Parameters.B;
Nx = size(A,1);
Nu = size(B,2);
Hxx = zeros(Nx,Nx,Nx);
Huu = zeros(Nu,Nu,Nx);
Hux = zeros(Nu,Nx,Nx);
Hxu = zeros(Nx,Nu,Nx);
end

