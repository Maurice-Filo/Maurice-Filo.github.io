function  f = f_LTI(~, x, u, f_Parameters)
% This function calculates f(x, u) = Ax + Bu where:
%           A = f_Parameters.A
%           B = f_Parameters.B
A = f_Parameters.A;
B = f_Parameters.B;
f = A*x + B*u;
end

