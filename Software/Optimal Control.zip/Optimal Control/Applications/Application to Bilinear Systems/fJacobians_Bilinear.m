function [A_k, B_k] = fJacobians_Bilinear(x_k, u_k, ~, f_Parameters)
% This function computes the partial derivatives of f(x,u) with respect to x and
% u for the bilinear systems evaluated at (x_k,u_k,t), that is
%       A_k = \frac{\partial}{\partial x} f(x_k,u_k)
%       B_k = \frac{\partial}{\partial x} f(x_k,u_k)
A = f_Parameters.A;
B = f_Parameters.B;
A_k = A + B*u_k;
B_k = B*x_k;
end

