function  f = f_Bilinear(~, x, u, f_Parameters)
% This function calculates f(x, u) = (A + Bu)x where:
%           A = f_Parameters.A
%           B = f_Parameters.B
A = f_Parameters.A;
B = f_Parameters.B;
f = (A + u*B)*x;
end

