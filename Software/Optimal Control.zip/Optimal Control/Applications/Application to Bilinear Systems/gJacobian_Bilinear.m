function [K] = gJacobian_Bilinear(x, g_Parameters)
GQ = g_Parameters.GQ;
K = -2 * x' * GQ;
end
