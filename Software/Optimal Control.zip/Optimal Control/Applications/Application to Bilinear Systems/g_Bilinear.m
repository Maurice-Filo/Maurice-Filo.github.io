function [g] = g_Bilinear(x, g_Parameters)
GQ = g_Parameters.GQ;
g = -sum(x .* (GQ * x));
end

