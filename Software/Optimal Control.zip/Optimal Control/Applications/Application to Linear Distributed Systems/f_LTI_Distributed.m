function  f = f_LTI_Distributed(t, x, u, f_Parameters)
% This function calculates f(x, u) = Ax + Bu + B0v where:
%           A = f_Parameters.A
%           B = f_Parameters.B
%           B0 = f_Parameters.B0
%           v = f_Parameters.v
A = f_Parameters.A;
B = f_Parameters.B;
B0 = f_Parameters.B0;
v = f_Parameters.v;
t_vector = f_Parameters.t_vector;
v = Vector_Interpolate(t_vector, v, t);
f = A*x + B*u + B0*v;
end

