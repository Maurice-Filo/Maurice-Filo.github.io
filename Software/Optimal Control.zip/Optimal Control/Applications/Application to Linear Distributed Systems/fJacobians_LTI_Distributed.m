function [A_k, B_k] = fJacobians_LTI_Distributed(~, ~, ~, f_Parameters)
% This function computes the partial derivatives of f(x,u) with respect to x and
% u for the Linear systems evaluated at (x_k,u_k,t), that is
%       A_k = \frac{\partial}{\partial x} f(x_k,u_k)
%       B_k = \frac{\partial}{\partial x} f(x_k,u_k)
A_k = f_Parameters.A;
B_k = f_Parameters.B;
end

