function [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_LTI_Distributed()
% This function generates the A and B matrices of the linear system of the form:
%                       dx = Ax + Bu + B0v
% The matrices A and B are stored as follows:   f_Parameters.A = A 
%                                               f_Parameters.B = B
%                                               f_Parameters.B0 = B0
% u as a control input and v is a fixed (uncontrollable) input. 
% The time horizon with the initial condition are returned as t_vector and
% x0, respsectively.

%% Time Discretization Parameters
tf = 15;
Nt = 1000;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Linear Model Parameters
sigma = 2;
L = 5;
% Space Discretization Parameters
N = 50;
dx = L / (N+1);
x_vector = 0 : dx : L;
alpha_vector = exp(-5*x_vector/L);
% Uncontrollable Input (Dirichlet Boundary Conditions)
v = [3*sin(2 * pi * t_vector) - 2; 3*sin(2 * (pi - 0.2) * t_vector) - 2];

%% Initial Conditions
x0 = -2 * ones(N,1);

%% Performance Index Parameters
Q = 1*eye(N);
epsilon = 1;
Q(5:45,5:45) = epsilon;
R = 1;

%% Forming A and B Matrices
A = (1 / dx)^2 * sparse([1:N, 2:N, 1:N-1], [1:N, 1:N-1, 2:N], [-2*ones(1,N), ones(1,N-1), ones(1,N-1)], N, N);
A = diag(alpha_vector(2:N+1).^2) * A;
B0 = (1 / dx)^2 * sparse([1 N], [1 2], [alpha_vector(1)^2 alpha_vector(N+2)^2], N, 2);
B = exp(-(1/(2 * sigma^2)) * (x_vector(2:N+1)' - (L/2)).^2);
f_Parameters.A = A;
f_Parameters.B = B;
f_Parameters.B0 = B0;
f_Parameters.v = v;
f_Parameters.x_vector = x_vector;
f_Parameters.t_vector = t_vector;
end

