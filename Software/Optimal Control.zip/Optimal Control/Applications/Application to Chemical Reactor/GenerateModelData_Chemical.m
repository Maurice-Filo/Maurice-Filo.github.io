function [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Chemical()
% The time horizon with the initial condition are returned as t_vector and
% x0, respsectively for the chemical reactor problem

%% Time Discretization Parameters
tf = 0.78;
Nt = 500;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Initial Conditions
x0 = [0.05 0]';

%% Performance Index Parameters
Q = [2,0; 0,2];
R = 0.2;
f_Parameters = [];
end

