function [A_k, B_k] = fJacobians_Chemical(x_k, u_k, ~, ~)
% This function computes the partial derivatives of f(x,u) with respect to x and
% u for the chemical reactor system evaluated at (x_k,u_k,t), that is
%       A_k = \frac{\partial}{\partial x} f(x_k,u_k)
%       B_k = \frac{\partial}{\partial x} f(x_k,u_k)
x1 = x_k(1);
x2 = x_k(2);
v = exp(25*x1 / (x1+2));
dv = 50*v / (x1+2)^2;
A_k = [-2 + (x2+0.5)*dv - u_k, v; -(x2+0.5)*dv, -1-v];
B_k = [-(x1+0.25); 0];
end

