function [Hxx, Hxu, Hux, Huu] = fHessians_Chemical(x_k, ~ , ~, ~)
% This function computes the partial second derivatives of f(x,u) with respect to x and
% u for the bilinear systems evaluated at (x_k,u_k,t), that is
%       Hxx = \frac{\partial^2}{\partial _{xx}} f(x_k,u_k)
%       Hux = \frac{\partial^2}{\partial _{xux}} f(x_k,u_k)
%       Hxu = \frac{\partial^2}{\partial _{xu}} f(x_k,u_k)
%       Huu = \frac{\partial^2}{\partial _{uu}} f(x_k,u_k)
% Note that in general these are 3D Matrices
x1 = x_k(1);
x2 = x_k(2);
v = exp(25*x1 / (x1+2));
dv = 50*v / (x1+2)^2;
ddv = 100*v*(23-x1) / (x1+2)^4;
Hxx(:,:,1) = [(x2+0.5)*ddv, dv; dv, 0];
Hxu(:,1,1) = [-1 0]';
Hux(1,:,1) = [-1 0];
Hxx(:,:,2) = [-(x2+0.5)*ddv, -dv; -dv, 0];
Huu = zeros(1,1,2);
Hux(1,:,2) = [0 0];
Hxu(:,1,2) = [0 0]';
end

