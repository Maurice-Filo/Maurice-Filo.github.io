function  f = f_Chemical(~, x, u, ~)
% This function calculates f(x, u) = [f1; f2] where:
%           f1(x,u) = -2(x1+0.25) + (x2+0.5)v(x1) - (x1+0.25)u
%           f2(x,u) = 0.5-x2 - (x2+0.5)v(x1)
%           v(x1) = exp(25x1 / (x1+2))
x1 = x(1);
x2 = x(2);
v = exp(25*x1 / (x1+2));
f1 = -2*(x1+0.25) + (x2+0.5)*v - (x1+0.25)*u;
f2 = 0.5-x2 - (x2+0.5)*v;
f = [f1; f2];
end

