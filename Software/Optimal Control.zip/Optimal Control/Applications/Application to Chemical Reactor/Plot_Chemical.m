%% Plotting Results for the Unconstrained Gradient Descent Method
figure();
suptitle('Chemical Reactor');
subplot 221
plot(t_vector, u_0, 'k', 'linewidth', 2);
hold on
plot(t_vector, u, 'b', 'linewidth', 2);
xlabel('t');
ylabel('u(t)');
legend('Initial Guess', 'Optimal Control');

subplot 222
plot(t_vector, x(1,:), 'g', 'linewidth', 2);
hold on
plot(t_vector, x(2,:), 'r', 'linewidth', 2);
xlabel('t');
ylabel('x(t)');
legend('x_1(t)', 'x_2(t)');

subplot 223;
semilogy(J, 'x-');
grid on;
xlabel('Iteration Number');
ylabel('J');

subplot 224;
plot(Step_History, 'kx-');
xlabel('Iteration Number');
ylabel('Step Size');
