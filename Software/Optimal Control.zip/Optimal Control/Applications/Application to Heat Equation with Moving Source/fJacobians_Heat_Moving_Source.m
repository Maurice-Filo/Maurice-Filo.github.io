function [A_k, B_k] = fJacobians_Heat_Moving_Source(x_k, u_k, ~, f_Parameters)
% This function computes the partial derivatives of f(x,u) with respect to x and
% u for the Heat Equation with a moving source evaluated at (x_k,u_k,t), that is
%       A_k = \frac{\partial}{\partial x} f(x_k,u_k)
%       B_k = \frac{\partial}{\partial x} f(x_k,u_k)
As = f_Parameters.As;
Bs = f_Parameters.Bs;
Cs = f_Parameters.Cs;
alpha = f_Parameters.alpha;
sigma = f_Parameters.sigma;
Dxxr = f_Parameters.Dxxr;
nx = f_Parameters.nx;
Ns = f_Parameters.Ns;
xi = f_Parameters.xi;
s = x_k(nx-1:nx+Ns-2);
xi = xi(2:nx-1);
gamma = exp(-((xi' - Cs*s).^2) / (2*sigma^2));
dgamma = ((1/sigma^2) * gamma .* (xi' - Cs*s)) * Cs;
A_k = [alpha^2 * Dxxr, u_k(1) * dgamma; zeros(Ns, nx-2), As];
B_k = [gamma, zeros(nx-2,1); zeros(Ns,1), Bs];
end

