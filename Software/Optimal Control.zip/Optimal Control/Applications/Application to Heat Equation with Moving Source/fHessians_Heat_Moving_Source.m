function [Hxx, Hux, Hxu, Huu] = fHessians_Heat_Moving_Source(x_k, u_k, ~, f_Parameters)
% This function computes the partial second derivatives of f(x,u) with respect to x and
% u for the heat equation with a moving source evaluated at (x_k,u_k,t), that is
%       Hxx = \frac{\partial^2}{\partial _{xx}} f(x_k,u_k)
%       Hux = \frac{\partial^2}{\partial _{xux}} f(x_k,u_k)
%       Hxu = \frac{\partial^2}{\partial _{xu}} f(x_k,u_k)
%       Huu = \frac{\partial^2}{\partial _{uu}} f(x_k,u_k)
% Note that in general these are 3D Matrices
Cs = f_Parameters.Cs;
sigma = f_Parameters.sigma;
nx = f_Parameters.nx;
Ns = f_Parameters.Ns;
xi = f_Parameters.xi;
s = x_k(nx-1:nx+Ns-2);
xi = xi(2:nx-1);
gamma = exp(-((xi' - Cs*s).^2) / (2*sigma^2));
dgamma = ((1/sigma^2) * gamma .* (xi' - Cs*s)) * Cs;
Hxx = zeros(nx+Ns-2, nx+Ns-2, nx+Ns-2);
Huu = zeros(2,2,nx+Ns-2);
Hxu = zeros(nx+Ns-2,2,nx+Ns-2);
Hux = zeros(2,nx+Ns-2,nx+Ns-2);
for i = 1 : nx-2
    ddgamma_i = (1/sigma^2) * gamma(i) * ((xi(i) - Cs*s)^2 / (sigma^2) - 1) * (Cs'*Cs);
    Hxx(:,:,i) = [zeros(nx-2,nx+Ns-2); zeros(Ns,nx-2), u_k(1)*ddgamma_i];
    Hxu(:,:,i) = [zeros(nx-2,2); dgamma(i,:)', zeros(Ns,1)];
    Hux(:,:,i) = [zeros(1,nx-2), dgamma(i,:); zeros(1,nx+Ns-2)];
end
end

