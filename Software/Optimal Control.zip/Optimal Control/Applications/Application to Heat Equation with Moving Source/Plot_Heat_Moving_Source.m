%% Plotting Results for the Unconstrained Gradient Descent Method
figure();
subtitle('Heat Equation with a Moving Source');
subplot 221
plot(t_vector, u_0(1,:), 'k', 'linewidth', 2);
hold on
plot(t_vector, u_0(2,:), 'k-.', 'linewidth', 2);
plot(t_vector, u(1,:), 'b', 'linewidth', 2);
plot(t_vector, u(2,:), 'r', 'linewidth', 2);
xlabel('t');
ylabel('u(t)');
legend('Initial Intensity Guess', 'Initial Velocity Guess', 'Optimal Intensity', 'Optimal Velocity');

subplot 222
x_vector = f_Parameters.x_vector;
nx = f_Parameters.nx;
xi = f_Parameters.xi;
Ns = f_Parameters.Ns;
X = [f_Parameters.Tb(1,:); x(1:nx-2,:); f_Parameters.Tb(2,:)];
XX = polyinterp(xi, X', x_vector);
XX = XX';
s = x(nx-1:nx+Ns-2,:);
Tmax = max(max(XX));
surf(t_vector, x_vector, XX);
hold on;
plot3(t_vector, s, Tmax*ones(length(t_vector),1), 'r', 'linewidth', 2);
shading interp;
xlabel('t');
ylabel('x');
zlabel('Temperature');
legend('Temperature', 'Trajectory');

subplot 223;
semilogy(J - J(end), 'x-');
grid on;
xlabel('Iteration Number');
ylabel('J');

subplot 224;
plot(Step_History, 'kx-');
xlabel('Iteration Number');
ylabel('Step Size');
