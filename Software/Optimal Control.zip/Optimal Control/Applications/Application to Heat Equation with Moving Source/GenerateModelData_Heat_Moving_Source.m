function [f_Parameters, t_vector, x0, Q, R] = GenerateModelData_Heat_Moving_Source()
% This function generates necessary data for a model of the heat equation
% with a moving source:
%    dT(x,t)/dt = alpha^2 d^2T(x,t)/dx^2 + u1(t) gamma(p(t)) for 0 < x < L  
%      ds(t)/dt = As s(t) + Bs u2(t)
%          p(t) = Cs s(t)
%                           T(0,t) = T1(t)       
%                           T(L,t) = T2(t)         
%                           T(x,0) = T0(x)
%           where gamma(p(t)) := exp(-(x - p(t))^2)/(2 sigma^2))
% Space is discretized using Chebyshev collocation.
%% Space Discretization Parameters
L = 5;
N = 100;
dx = L / (N+1);
x_vector = 0 : dx : L;
nx = 20;                                             % Number of Spatial Collocation Nodes
type = 2;                                            % Type of Collocation Nodes
xi = CollocationNodes(x_vector(1), x_vector(end), nx, type);
Dx = Derivative_Matrix(xi);
Dxx = Dx * Dx;
Dxxr = Dxx(2:nx-1,2:nx-1);
Dxxb = [Dxx(2:nx-1,1) Dxx(2:nx-1,nx)];

%% Time Discretization Parameters
tf = 15;
Nt = 1000;
dt = tf / (Nt+1);
t_vector = 0 : dt : tf;

%% Model Parameters
alpha = 0.8;
sigma = 0.2;
As = 0;
Bs = 1;
Cs = 1;
Ns = size(As,1);
% Uncontrollable Input (Dirichlet Boundary Conditions)
T1 = 3*sin(2 * pi * t_vector) - 4;
T2 = 2*sin(2 * (pi - 0.2) * t_vector) - 4;
Tb = [T1; T2];
% Initial Conditions
psi0 = -4 * ones(nx,1);
s0 = L/5;
x0 = [psi0(2:nx-1); s0];

%% Performance Index Parameters
Q = [10 * eye(nx-2) zeros(nx-2,Ns); zeros(Ns,nx-2) 2*eye(Ns,Ns)];
R = [1 0; 0 2];

%% Forming A and B Matrices
f_Parameters.alpha = alpha;
f_Parameters.sigma = sigma;
f_Parameters.Dxxr = Dxxr;
f_Parameters.Dxxb = Dxxb;
f_Parameters.As = As;
f_Parameters.Bs = Bs;
f_Parameters.Cs = Cs;
f_Parameters.Tb = Tb;
f_Parameters.x_vector = x_vector;
f_Parameters.t_vector = t_vector;
f_Parameters.xi = xi;
f_Parameters.nx = nx;
f_Parameters.Ns = Ns;
end


