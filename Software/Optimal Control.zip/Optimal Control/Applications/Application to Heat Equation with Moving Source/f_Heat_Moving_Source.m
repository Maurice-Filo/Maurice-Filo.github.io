function  f = f_Heat_Moving_Source(t, X, u, f_Parameters)
% This function calculates f(x,u,t) for the dynamical model of the heat
% equation with a moving source
As = f_Parameters.As;
Bs = f_Parameters.Bs;
Cs = f_Parameters.Cs;
alpha = f_Parameters.alpha;
sigma = f_Parameters.sigma;
Dxxr = f_Parameters.Dxxr;
Dxxb = f_Parameters.Dxxb;
nx = f_Parameters.nx;
Ns = f_Parameters.Ns;
Tb = f_Parameters.Tb;
xi = f_Parameters.xi;
t_vector = f_Parameters.t_vector;
Tb = Vector_Interpolate(t_vector, Tb, t);
psi = X(1:nx-2);
s = X(nx-1:nx+Ns-2);
u1 = u(1);
u2 = u(2);
xi = xi(2:nx-1);
gamma = exp(-((xi' - Cs*s).^2) / (2*sigma^2));
f1 = alpha^2 * Dxxr * psi + Dxxb * Tb + u1 * gamma;
f2 = As*s + Bs*u2;
f = [f1; f2];
end

