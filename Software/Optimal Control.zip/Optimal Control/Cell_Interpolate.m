function [X_t] = Cell_Interpolate(t_vector, X, t)
for k = 1 : length(t_vector)
    if (t_vector(k) > t)
        break;
    end
end
if k == 1
    X_t = X{k};
else
    X_t = ((X{k} - X{k-1}) / (t_vector(k) - t_vector(k-1))) * (t - t_vector(k-1)) + X{k-1};
end
end

