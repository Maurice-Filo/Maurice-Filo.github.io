function p = InnerProduct(x1, x2, t_vector)
dt = t_vector(2) - t_vector(1);
Nt = length(t_vector) - 2;
w = ones(1,Nt+2);
w(1) = 1/2;
w(Nt+2) = 1/2;
p = 0;
for i = 1 : Nt+2
    p = p + x1(:,i)' * x2(:,i) * w(i) * dt;
end

