function [x] = StateEquation(t_vector, u, x0, f, f_Parameters)
% This function integrates the differential equation dx = f(x,u,t)
%   f is the handle of the right hand side function
%   x0 is the initial condition
%   u is an input with its time horizon t_vector
%   f_Parameters are additional parameters passed to be used by f
[~, x] = ode45(@(t, x) ft(t, x, t_vector, u, f, f_Parameters), t_vector, x0); 
x = x';
end

function dx = ft(t, x, t_vector, u, f, f_Parameters)
u = Vector_Interpolate(t_vector, u, t);
dx = f(t, x, u, f_Parameters);
end