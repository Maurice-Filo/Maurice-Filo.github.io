function [A11, A12, A21, A22, b1, b2] = f_TPBVP_PCGD(t_vector, t, TPBVP_Parameters)
% This function computes the matrices and vectors of the TPBVP that emerges from the
% optimal control problem of the PPGD Method.
% The matrices and vectors are calculated at a given time instant t using the parameters 
% in the structure TPBVP_Parameters.
%               dx(t)dt = A(t) x(t) + b(t)
%                  u(t) = M(t) x(t) + v(t)
%                           where: x(t) = [x1(t)' x2(t)']'
%                           A(t) = [A11(t) A12(t); A21(t) A22(t)]
%                           b(t) = [b1(t); b2(t)]
%                           M(t) = [M1(t) M2(t)]
%% Loading the Parameters of the TPBVP
Q = TPBVP_Parameters.Q;
R = TPBVP_Parameters.R;
u_k = TPBVP_Parameters.u_k;
x_k = TPBVP_Parameters.x_k;
fJacobians = TPBVP_Parameters.fJacobians;
f_Parameters = TPBVP_Parameters.f_Parameters;
%% Computing the Jacobians and Hessians at time t
x_k = Vector_Interpolate(t_vector, x_k, t);
u_k = Vector_Interpolate(t_vector, u_k, t);
[A_k, B_k] = fJacobians(x_k, u_k, t, f_Parameters);
%% Computing the Matrices and Vectors
A11 = A_k;
A12 = -B_k * (R \ B_k');
A21 = -Q;
A22 = -A_k';
b1 =  -B_k * u_k;
b2 =  -Q * x_k;
end

