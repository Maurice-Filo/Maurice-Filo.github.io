function [M, v] = f_TPBVP_Algebraic_PCGD(t_vector, t, TPBVP_Parameters)
% This function computes the matrix and vector of the algebraic equation 
% of the TPBVP that emerges from the optimal control problem of the PPGD Method.
% The matricx M and vector v are calculated at a given time instant t using the parameters 
% in the structure TPBVP_Parameters.
%               dx(t)dt = A(t) x(t) + b(t)
%                  u(t) = M(t) x(t) + v(t)
%                           where: x(t) = [x1(t)' x2(t)']'
%                           A(t) = [A11(t) A12(t); A21(t) A22(t)]
%                           b(t) = [b1(t); b2(t)]
%                           M(t) = [M1(t) M2(t)]
%% Loading the Parameters of the TPBVP
R = TPBVP_Parameters.R;
u_k = TPBVP_Parameters.u_k;
x_k = TPBVP_Parameters.x_k;
fJacobians = TPBVP_Parameters.fJacobians;
f_Parameters = TPBVP_Parameters.f_Parameters;
%% Computing the Jacobians and Hessians at time t
x_k = Vector_Interpolate(t_vector, x_k, t);
u_k = Vector_Interpolate(t_vector, u_k, t);
[~, B_k] = fJacobians(x_k, u_k, t, f_Parameters);
Nx = size(x_k,1);
Nu = size(u_k,1);
%% Computing the Matrices and Vectors
M = -R \ [zeros(Nu,Nx), B_k'];
v = -R \ (R*u_k);
end

