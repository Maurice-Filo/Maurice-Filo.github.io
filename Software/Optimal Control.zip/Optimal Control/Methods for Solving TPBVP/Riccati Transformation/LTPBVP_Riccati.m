function [x1, x2, u] = LTPBVP_Riccati(t_vector, f_TPBVP, f_TPBVP_Algebraic, TPBVP_Parameters, x10, x2T)
% This function solves a Linear Two Point Boundary Value Problem using Riccati Transformation:
%               dx(t)dt = A(t) x(t) + b(t)
%                  u(t) = M(t) x(t) + v(t)
%                   such that: x1(0) = x10 and x2(T) = x2T
%                           where: x(t) = [x1(t)' x2(t)']'
%                           A(t) = [A11(t) A12(t); A21(t) A22(t)]
%                           b(t) = [b1(t); b2(t)]
%                           M(t) = [M1(t) M2(t)]
% The function handle f_TPBVP uses the
% structure TPBVP_Parameters to calculate the corresponding matrices and
% vectors at some given time instant t.

Nt = length(t_vector) - 2;
Nx = size(TPBVP_Parameters.Q,1);
Nu = size(TPBVP_Parameters.R,1);
if (nargin == 4)
    x10 = zeros(Nx,1);
    x2T = zeros(Nx,1);
end
[~, X] = ode45(@(t, X) Riccati_Transformation(t, X, t_vector, f_TPBVP, TPBVP_Parameters, Nx), t_vector, [zeros(Nx^2,1); x10]); 
P_vec = X(:,1:Nx^2)';
w = X(:,Nx^2+1:Nx^2+Nx)';
P = cell(1,Nt+2);
for k = 1 : Nt+2
    P{k} = reshape(P_vec(:,k), Nx, Nx);
end
[~, x2] = ode45(@(t, x2) Solve_For_x2(t, x2, t_vector, f_TPBVP, P, w, TPBVP_Parameters), flip(t_vector), x2T); 
x2 = flip(x2)';
x1 = zeros(Nx,Nt+2);
u = zeros(Nu,Nt+2);
for k = 1 : Nt + 2
    x1(:,k) = P{k}*x2(:,k) + w(:,k);
    t = t_vector(k);
    [M, v] = f_TPBVP_Algebraic(t_vector, t, TPBVP_Parameters);
    u(:,k) = M*[x1(:,k); x2(:,k)] + v;
end
end

function dX = Riccati_Transformation(t, X, t_vector, f_TPBVP, TPBVP_Parameters, N)
P_vec = X(1:N^2);
w = X(N^2+1:N^2+N);
[A11, A12, A21, A22, b1, b2] = f_TPBVP(t_vector, t, TPBVP_Parameters);
P = reshape(P_vec, N, N);
dP = A11*P - P*A22 - P*A21*P + A12;
dP_vec = reshape(dP, N^2, 1);
dw = (A11 - P*A21)*w + b1 - P*b2;
dX = [dP_vec; dw];
end

function dx2 = Solve_For_x2(t, x2, t_vector, f_TPBVP, P, w, TPBVP_Parameters)
[~, ~, A21, A22, ~, b2] = f_TPBVP(t_vector, t, TPBVP_Parameters);
P = Cell_Interpolate(t_vector, P, t);
w = Vector_Interpolate(t_vector, w, t);
dx2 = (A21*P + A22)*x2 + A21*w + b2;
end