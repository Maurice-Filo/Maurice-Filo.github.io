function [D] = Derivative_Matrix(t)
% This function computes the derivative matrix that acts on a vector of
% function evaluations at the collocation points t and yields a vector of
% the derivative of the function evaluated at the collocation points t

n = length(t); 
D = zeros(n,n);
for l = 1 : n
    for i = 1 : n
        if i == l
            for j = [1:i-1 i+1:n]
                D(i,i) = D(i,i) + 1 / (t(i) - t(j));
            end
        else
            D(l,i) = 1;
            for j = 1 : n
                if (j == i) || (j == l)
                    continue;
                else
                    D(l,i) = D(l,i) * (t(l) - t(j)) / (t(i) - t(j));
                end
            end
            D(l,i) = D(l,i) / (t(i) - t(l));
        end
    end
end

end

