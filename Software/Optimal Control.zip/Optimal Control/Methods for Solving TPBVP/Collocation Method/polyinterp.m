function xi = polyinterp(t,x,ti)
%POLYINTERP  Polynomial interpolation.
%   v = POLYINTERP(x,y,u) computes v(j) = P(u(j)) where P is the
%   polynomial of degree d = length(x)-1 with P(x(i)) = y(i).

%   Copyright 2014 Cleve Moler
%   Copyright 2014 The MathWorks, Inc.

% Use Lagrangian representation.
% Evaluate at all elements of u simultaneously.

n = length(t);
Nx = size(x,1);
xi = zeros(size(x,1), length(ti));
for k = 1:n
   w = ones(1,length(ti));
   for j = [1:k-1 k+1:n]
        w = (ti-t(j))./(t(k)-t(j)).*w;
   end
   for nx = 1 : Nx
        xi(nx,:) = xi(nx,:) + w*x(nx,k);
   end;
end
