function [x1, x2, u] = LTPBVP_Collocation(t_vector, f_TPBVP, f_TPBVP_Algebraic, TPBVP_Parameters, D, ti, Nx, Nu)
% This function solves a Linear Two Point Boundary Value Problem using a collocation method:
%               dx(t)dt = A(t) x(t) + b(t)
%                  u(t) = M(t) x(t) + v(t)
%                   such that: x1(0) = 0 and x2(T) = 0
%                           where: x(t) = [x1(t)' x2(t)']'
%                           A(t) = [A11(t) A12(t); A21(t) A22(t)]
%                           b(t) = [b1(t); b2(t)]
%                           M(t) = [M1(t) M2(t)]
% The function handle f_TPBVP uses the
% structure TPBVP_Parameters to calculate the corresponding matrices and
% vectors at some given time instant t. D is the derivative matrix
% corresponding to the collocation nodes in vector ti.
n = length(ti);
A11 = zeros(n*Nx,n*Nx);
A12 = zeros(n*Nx,n*Nx);
A21 = zeros(n*Nx,n*Nx);
A22 = zeros(n*Nx,n*Nx);
b1 = zeros(n*Nx,1);
b2 = zeros(n*Nx,1);
for i = 1 : n
    t = ti(i);
    i1 = (i-1)*Nx + 1;
    i2 = i*Nx;
    [A11t, A12t, A21t, A22t, b1t, b2t] = f_TPBVP(t_vector, t, TPBVP_Parameters);
    A11(i1:i2,i1:i2) = A11t;
    A12(i1:i2,i1:i2) = A12t;
    A21(i1:i2,i1:i2) = A21t;
    A22(i1:i2,i1:i2) = A22t;
    b1(i1:i2,1) = b1t;
    b2(i1:i2,1) = b2t;
end
A11 = A11(Nx+1:n*Nx,Nx+1:n*Nx);
A12 = A12(Nx+1:n*Nx,1:(n-1)*Nx);
A21 = A21(1:(n-1)*Nx,Nx+1:n*Nx);
A22 = A22(1:(n-1)*Nx,1:(n-1)*Nx);
b1 = b1(Nx+1:n*Nx);
b2 = b2(1:(n-1)*Nx);
D0 = D(2:n, 2:n);
DT = D(1:n-1, 1:n-1);
Matrix = [kron(D0,eye(Nx)) - A11, -A12; -A21, kron(DT,eye(Nx)) - A22];
Vector = [b1; b2];
Z = Matrix \ Vector;
X1 = Z(1:(n-1)*Nx);
X2 = Z((n-1)*Nx+1:end);
x1 = [zeros(Nx,1), reshape(X1, Nx, n-1)];
x2 = [reshape(X2, Nx, n-1), zeros(Nx,1)];
x1 = polyinterp(ti, x1, t_vector);
x2 = polyinterp(ti, x2, t_vector);

Nt = length(t_vector) - 2;
u = zeros(Nu,Nt+2);
for k = 1 : Nt+2
    t = t_vector(k);
    [M, v] = f_TPBVP_Algebraic(t_vector, t, TPBVP_Parameters);
    u(:,k) = M*[x1(:,k); x2(:,k)] + v;
end
end


