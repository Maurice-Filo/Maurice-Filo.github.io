function [t] = CollocationNodes(a, b, n, type)
% This function returns the n collocation points in the interval
% [a, b]. type can take four values:
%               type = 1 for roots of Chebyshev polynomials of type 1
%               type = 2 for roots of Chebyshev polynomials of type 2
%               type = 3 for roots of Legendre polynomials
%               type = 4 for equally spaced grid points
if type == 1
    n = n+2;
    k = 1 : n-2;
    t = 0.5 * (a + b) - 0.5 * (b - a) * cos((2*k-1)*pi / (2*(n-2)));
%     x = [a x b];
elseif type == 2
    k = 0 : n-1;
    t = 0.5 * (a + b) - 0.5 * (b - a) * cos(k*pi / (n-1));
elseif type == 3
    i   = 1:n-1;
    c   = i./sqrt(4*i.^2-1);
    CM  = diag(c,1) + diag(c,-1);           % Companion Matrix
    t = sort(eig(CM))';
    t = 0.5 * (a + b) + 0.5 * (b - a) * t;
%     x = [a x b];
elseif type == 4
    dx = (b - a) / (n - 1);
    t = a : dx : b;
else
    error('type should take values of 1, 2 or 3');
end
end

