%% Clearing Workspace
close all;
clear;
clc;

%% Test Function
% f = @(t) exp(-t/3).*sin(2*pi*t/4);
% df = @(t) -(exp(-t/3).*(2*sin((pi*t)/2) - 3*pi*cos((pi*t)/2)))/6;
% t0 = 0;
% tf = 10;
% dt = 0.01; 
f = @(t) 1./ (1 + 25*t.^2);
df = @(t)-(50*t)./(25*t.^2 + 1).^2;
t0 = -1;
tf = 1;
dt = 0.01;
t_vector = t0 : dt : tf;

%% Comparison Between Different Collocation Points
xe = f(t_vector);
dxe = df(t_vector);
n_vector = 5 : 1 : 150;
y_Cheb1 = zeros(length(n_vector), length(t_vector));
y_Cheb2 = zeros(length(n_vector), length(t_vector));
y_Legendre = zeros(length(n_vector), length(t_vector));
y_Equal = zeros(length(n_vector), length(t_vector));
ErrorL2_Cheb1 = zeros(1,length(n_vector));
ErrorL2_Cheb2 = zeros(1,length(n_vector));
ErrorL2_Legendre = zeros(1,length(n_vector));
ErrorL2_Equal = zeros(1,length(n_vector));
ErrorL2_Chebfun = zeros(1,length(n_vector));
ErrorLinf_Cheb1 = zeros(1,length(n_vector));
ErrorLinf_Cheb2 = zeros(1,length(n_vector));
ErrorLinf_Legendre = zeros(1,length(n_vector));
ErrorLinf_Equal = zeros(1,length(n_vector));
ErrorLinf_Chebfun = zeros(1,length(n_vector));
dy_Cheb1 = zeros(length(n_vector), length(t_vector));
dy_Cheb2 = zeros(length(n_vector), length(t_vector));
dy_Legendre = zeros(length(n_vector), length(t_vector));
dy_Equal = zeros(length(n_vector), length(t_vector));
dErrorL2_Cheb1 = zeros(1,length(n_vector));
dErrorL2_Cheb2 = zeros(1,length(n_vector));
dErrorL2_Legendre = zeros(1,length(n_vector));
dErrorL2_Equal = zeros(1,length(n_vector));
dErrorL2_Chebfun = zeros(1,length(n_vector));
dErrorLinf_Cheb1 = zeros(1,length(n_vector));
dErrorLinf_Cheb2 = zeros(1,length(n_vector));
dErrorLinf_Legendre = zeros(1,length(n_vector));
dErrorLinf_Equal = zeros(1,length(n_vector));
dErrorLinf_Chebfun = zeros(1,length(n_vector));
for i = 1 : length(n_vector)
    n = n_vector(i)
    % Different Collocation Points
    t_Cheb1 = CollocationNodes(t0, tf, n, 1);
    t_Cheb2 = CollocationNodes(t0, tf, n, 2);
    t_Legendre = CollocationNodes(t0, tf, n, 3);
    t_Equal = CollocationNodes(t0, tf, n, 4);
    % Data at Collocation Points
    x_Cheb1 = f(t_Cheb1);
    x_Cheb2 = f(t_Cheb2);
    x_Legendre = f(t_Legendre);
    x_Equal = f(t_Equal);
    % Polynomial Interpolation
    y_Cheb1(i,:) = polyinterp(t_Cheb1, x_Cheb1, t_vector);
    y_Cheb2(i,:) = polyinterp(t_Cheb2, x_Cheb2, t_vector);
    y_Legendre(i,:) = polyinterp(t_Legendre, x_Legendre, t_vector);
    y_Equal(i,:) = polyinterp(t_Equal, x_Equal, t_vector);
    % Error using L2 Norm
    ErrorL2_Cheb1(i) = norm(xe - y_Cheb1(i,:)) / norm(xe);
    ErrorL2_Cheb2(i) = norm(xe - y_Cheb2(i,:)) / norm(xe);
    ErrorL2_Legendre(i) = norm(xe - y_Legendre(i,:)) / norm(xe);
    ErrorL2_Equal(i) = norm(xe - y_Equal(i,:)) / norm(xe);
    % Error using L infinity Norm
    ErrorLinf_Cheb1(i) = max(xe - y_Cheb1(i,:)) / max(xe);
    ErrorLinf_Cheb2(i) = max(xe - y_Cheb2(i,:)) / max(xe);
    ErrorLinf_Legendre(i) = max(xe - y_Legendre(i,:)) / max(xe);
    ErrorLinf_Equal(i) = max(xe - y_Equal(i,:)) / max(xe);
    % Construction of Differentiation Matrices
    D_Cheb1 = Derivative_Matrix(t_Cheb1);
    D_Cheb2 = Derivative_Matrix(t_Cheb2);
    D_Legendre = Derivative_Matrix(t_Legendre);
    D_Equal = Derivative_Matrix(t_Equal);
    % Calculating the Derivatives at Collocation Points
    dx_Cheb1 = (D_Cheb1 * x_Cheb1')';
    dx_Cheb2 = (D_Cheb2 * x_Cheb2')';
    dx_Legendre = (D_Legendre * x_Legendre')';
    dx_Equal = (D_Equal * x_Equal')';
    % Polynomial Interpolation of the derivatives
    dy_Cheb1(i,:) = polyinterp(t_Cheb1, dx_Cheb1, t_vector);
    dy_Cheb2(i,:) = polyinterp(t_Cheb2, dx_Cheb2, t_vector);
    dy_Legendre(i,:) = polyinterp(t_Legendre, dx_Legendre, t_vector);
    dy_Equal(i,:) = polyinterp(t_Equal, dx_Equal, t_vector);
    % Error using L2 Norm of the Derivatives
    dErrorL2_Cheb1(i) = norm(dxe - dy_Cheb1(i,:)) / norm(dxe);
    dErrorL2_Cheb2(i) = norm(dxe - dy_Cheb2(i,:)) / norm(dxe);
    dErrorL2_Legendre(i) = norm(dxe - dy_Legendre(i,:)) / norm(dxe);
    dErrorL2_Equal(i) = norm(dxe - dy_Equal(i,:)) / norm(dxe);
    % Error using L infinity Norm of the Derivatives
    dErrorLinf_Cheb1(i) = max(dxe - dy_Cheb1(i,:)) / max(dxe);
    dErrorLinf_Cheb2(i) = max(dxe - dy_Cheb2(i,:)) / max(dxe);
    dErrorLinf_Legendre(i) = max(dxe - dy_Legendre(i,:)) / max(dxe);
    dErrorLinf_Equal(i) = max(dxe - dy_Equal(i,:)) / max(dxe);
end

%% Plotting the Results
suptitle('Polynomial Interpolation of x(t)');
subplot 221
plot(t_vector, xe, 'b', 'linewidth', 3);
hold on
plot(t_vector, y_Cheb1, 'r');
xlabel('t');
ylabel('x(t)');
legend('Exact', 'Cheb Type1');
subplot 222
plot(t_vector, xe, 'b', 'linewidth', 3);
hold on
plot(t_vector, y_Cheb2, 'r');
xlabel('t');
ylabel('x(t)');
legend('Exact', 'Cheb Type2');
subplot 223
plot(t_vector, xe, 'b', 'linewidth', 3);
hold on
plot(t_vector, y_Legendre, 'r');
xlabel('t');
ylabel('x(t)');
legend('Exact', 'Legendre');
subplot 224
plot(t_vector, xe, 'b', 'linewidth', 3);
hold on
plot(t_vector, y_Equal, 'r');
xlabel('t');
ylabel('x(t)');
legend('Exact', 'Equal Spacing');

figure();
suptitle('Interpolation Error');
subplot 121 
plot(n_vector, ErrorL2_Cheb1, 'b');
hold on;
plot(n_vector, ErrorL2_Cheb2, 'r');
plot(n_vector, ErrorL2_Legendre, 'm');
plot(n_vector, ErrorL2_Equal, 'k');
plot(n_vector, ErrorL2_Chebfun, 'g');
xlabel('Collocation Points');
ylabel('L_2 Error');
legend('Cheb1', 'Cheb2', 'Legendre', 'Equal');
set(gca, 'yscale', 'log');
grid on
subplot 122 
plot(n_vector, ErrorLinf_Cheb1, 'b');
hold on;
plot(n_vector, ErrorLinf_Cheb2, 'r');
plot(n_vector, ErrorLinf_Legendre, 'm');
plot(n_vector, ErrorLinf_Equal, 'k');
plot(n_vector, ErrorLinf_Chebfun, 'g');
xlabel('Collocation Points');
ylabel('L_{\infty} Error');
legend('Cheb Type1', 'Cheb Type2', 'Legendre', 'Equal Spacing');
set(gca, 'yscale', 'log');
grid on

figure();
suptitle('Calculating the Derivative Using Collocation');
subplot 221
plot(t_vector, dxe, 'b', 'linewidth', 3);
hold on
plot(t_vector, dy_Cheb1, 'r');
xlabel('t');
ylabel('$\frac{d}{dt} x(t)$', 'interpreter', 'latex');
legend('Exact', 'Cheb Type1');
subplot 222
plot(t_vector, dxe, 'b', 'linewidth', 3);
hold on
plot(t_vector, dy_Cheb2, 'r');
xlabel('t');
ylabel('$\frac{d}{dt} x(t)$', 'interpreter', 'latex');
legend('Exact', 'Cheb Type2');
subplot 223
plot(t_vector, dxe, 'b', 'linewidth', 3);
hold on
plot(t_vector, dy_Legendre, 'r');
xlabel('t');
ylabel('$\frac{d}{dt} x(t)$', 'interpreter', 'latex');
legend('Exact', 'Legendre');
subplot 224
plot(t_vector, dxe, 'b', 'linewidth', 3);
hold on
plot(t_vector, dy_Equal, 'r');
xlabel('t');
ylabel('$\frac{d}{dt} x(t)$', 'interpreter', 'latex');
legend('Exact', 'Equal Spacing');

figure();
suptitle('Derivative Error');
subplot 121 
plot(n_vector, dErrorL2_Cheb1, 'b');
hold on;
plot(n_vector, dErrorL2_Cheb2, 'r');
plot(n_vector, dErrorL2_Legendre, 'm');
plot(n_vector, dErrorL2_Equal, 'k');
plot(n_vector, dErrorL2_Chebfun, 'g');
xlabel('Number of Collocation Points');
ylabel('L_2 Error');
legend('Cheb Type1', 'Cheb Type2', 'Legendre', 'Equal Spacing');
set(gca, 'yscale', 'log');
grid on
subplot 122 
plot(n_vector, dErrorLinf_Cheb1, 'b');
hold on;
plot(n_vector, dErrorLinf_Cheb2, 'r');
plot(n_vector, dErrorLinf_Legendre, 'm');
plot(n_vector, dErrorLinf_Equal, 'k');
plot(n_vector, dErrorLinf_Chebfun, 'g');
xlabel('Number of Collocation Points');
ylabel('L_{\infty} Error');
legend('Cheb1', 'Cheb2', 'Legendre', 'Equal');
set(gca, 'yscale', 'log');
grid on