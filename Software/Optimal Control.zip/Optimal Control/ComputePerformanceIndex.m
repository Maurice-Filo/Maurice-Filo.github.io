function J = ComputePerformanceIndex(t_vector, x, u, Q, R)
% This function calculates the performance index of the following form:
%           J(x,u) = (1/2) (<x,Qx> + <u,Ru>) 
% The integrals are calculated using the first order finite difference method.
dt = t_vector(2) - t_vector(1);
Nt = length(t_vector) - 2;
w = ones(1,Nt+2);
w(1) = 1/2;
w(Nt+2) = 1/2;
J = 0;
for i = 1 : Nt+2
    J = J + ((x(:,i)' * Q * x(:,i) + u(:,i)' * R * u(:,i)) * dt / 2) * w(i);
end
end
