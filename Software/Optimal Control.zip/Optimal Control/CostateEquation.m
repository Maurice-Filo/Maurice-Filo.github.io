function [mu] = CostateEquation_Uc(t_vector, x_k, u_k, muT, fJacobians, f_Parameters, Q)
% This function integrates the adjoint differential equation 
%               \frac{d}{dt}\mu = -A_k^T \mu - Qx_k
%   fJacobians is the handle of the function that computes Jacobians of f: A_k and B_k
%   muT is the final condition
%   (x_k,u_k) is the state-control pair with its time horizon t_vector
%   f_Parameters are additional parameters passed to be used by fJacobians
[~, mu] = ode45(@(t, mu) f_Adjoint(t, mu, t_vector, x_k, u_k, fJacobians, f_Parameters, Q), flip(t_vector), muT); 
mu = flip(mu)';
end

function  dmu = f_Adjoint(t, mu, t_vector, x_k, u_k, fJacobians, f_Parameters, Q)
x_k = Vector_Interpolate(t_vector, x_k, t);
u_k = Vector_Interpolate(t_vector, u_k, t);
[A_k, ~] = fJacobians(x_k, u_k, t, f_Parameters);
dmu = -A_k'*mu - Q*x_k;
end