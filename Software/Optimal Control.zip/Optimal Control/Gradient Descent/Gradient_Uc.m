function [Gradient, mu_k] = Gradient_Uc(Q, R, u_k, x_k, t_vector, muT, fJacobians, f_Parameters)
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
mu_k = CostateEquation(t_vector, x_k, u_k, muT, fJacobians, f_Parameters, Q);
Nt = length(t_vector) - 2;
Gradient = zeros(size(u_k,1), Nt+2);
for i = 1 : Nt+2
    [~, B_k] = fJacobians(x_k(:,i), u_k(:,i), t_vector(i), f_Parameters);
    Gradient(:,i) = R*u_k(:,i) + B_k' * mu_k(:,i);
end
end

