function [alpha] = ArmijoBacktrack_Uc(tau, beta, alpha_Init, du, Gradient, Q, R, t_vector, u, x0, f, f_Parameters)
x = StateEquation(t_vector, u, x0, f, f_Parameters);
J = ComputePerformanceIndex(t_vector, x, u, Q, R);
Projection = InnerProduct(du, Gradient, t_vector);
alpha = alpha_Init;
u_new = u + alpha*du;
x_new = StateEquation(t_vector, u_new, x0, f, f_Parameters);
J_new = ComputePerformanceIndex(t_vector, x_new, u_new, Q, R);
while(J_new > J + alpha*beta*Projection)
    alpha = tau*alpha;
    u_new = u + alpha*du;
    x_new = StateEquation(t_vector, u_new, x0, f, f_Parameters);
    J_new = ComputePerformanceIndex(t_vector, x_new, u_new, Q, R);
end
end
