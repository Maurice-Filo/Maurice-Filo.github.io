function [x1, x2] = LTPBVP_FD(t_vector, A11, A12, A21, A22, b1, b2, x10, x2T)
% This function solves a Linear Two Point Boundary Value Problem using first order finite differences:
%               dx(t)dt = A(t) x(t) + b(t)
%                   such that: x1(0) = x10 and x2(T) = x2T
%                           where: x(t) = [x1(t)' x2(t)']'
%                           A(t) = [A11(t) A12(t); A21(t) A22(t)]
%                           b(t) = [b1(t); b2(t)]
% The generally time varying matrices Aij and vectors bi are given as cells
% and vectors, respectively such that Aij{k} = Aij(t_vector(k)) and bi(:,k) = bi(t_vector(k)) 
% where t_vector is the time horizon vector.
Nt = length(t_vector) - 2;
N = size(A11{1},1);
dt = t_vector(2) - t_vector(1);
M = sparse(2*N*(Nt-1),2*N*Nt);
y = sparse(2*N*(Nt-1),1);
I1 = speye(N);
I2 = speye(2*N);
for k = 2 : Nt
    M(2*N*(k-2) + 1 : 2*N*(k-1), 2*N*(k-2) + 1 : 2*N*k) = [-I2 - dt*[A11{k} A12{k}; A21{k} A22{k}], I2];
    y(2*N*(k-2) + 1 : 2*N*(k-1),1) = dt*[b1(:,k); b2(:,k)];
end
M1 = [[-dt*A12{1}; -I1 - dt*A22{1}], I2, sparse(2*N,N*(2*Nt-1))];
MEnd = [sparse(2*N,N*(2*Nt-1)), -I2 - dt*[A11{Nt+1} A12{Nt+1}; A21{Nt+1} A22{Nt+1}], [I1; sparse(N,N)]];
M = [M1; sparse(2*N*(Nt-1),N), M, sparse(2*N*(Nt-1),N); MEnd];
y1 = dt*[b1(:,k); b2(:,k)] + [x10 + dt*A11{1}*x10; dt*A21{1}*x10];
yEnd = [dt*b1(:,Nt+1); dt*b2(:,Nt+1) - x2T];
y = [y1; y; yEnd];
X = M \ y;
x = zeros(2*N, Nt);
for k = 2 : Nt+1
    x(:,k-1) = X(N+(k-2)*(2*N)+1:N+2*(k-1)*N);
end
x1 = [x10, x(1:N,:), X(end - N+1:end)];
x2 = [X(1:N), x(N+1:end,:), x2T];
end