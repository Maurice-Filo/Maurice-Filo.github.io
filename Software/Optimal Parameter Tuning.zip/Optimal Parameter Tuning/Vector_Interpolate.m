function [V_t] = Vector_Interpolate(t_vector, V, t)
n = length(t);
V_t = zeros(size(V,1), n);
for i = 1 : n
    ti = t(i);
    for k = 1 : length(t_vector)
        if (t_vector(k) > ti)
            break;
        end
    end
    if k == 1
        V_t(:,i) = V(:,k);
    else
        V_t(:,i) = ((V(:,k) - V(:,k-1)) / (t_vector(k) - t_vector(k-1))) * (ti - t_vector(k-1)) + V(:,k-1);
    end
end
end
