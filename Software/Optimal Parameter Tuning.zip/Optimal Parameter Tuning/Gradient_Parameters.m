function [grad, y] = Gradient_Parameters(Theta, t_vector, yr, Q, R, Plant_Parameters, v, x0, z0, f, g, h, kappa, PlantJacobians, ControllerJacobians, Solver)
%This function computes the gradient of the cost functional with respect
%to the parameter vector Theta.
    m = Plant_Parameters.m;
    nc = length(z0);
    p = length(Theta);
    [x, z, ~, y] = Simulate_ClosedLoop(Theta, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver);
    if strcmp(Solver, 'ODE15s')
        [~, X] = ode15s(@(t, X) RHS_Backward_Function(t, X, Theta, t_vector, yr, Q, x, z, Plant_Parameters, v, p, nc, m, PlantJacobians, ControllerJacobians, h, kappa), flip(t_vector), [0*x0; 0*z0; 0*Theta]);
    elseif strcmp(Solver, 'ODE23s')
        [~, X] = ode23s(@(t, X) RHS_Backward_Function(t, X, Theta, t_vector, yr, Q, x, z, Plant_Parameters, v, p, nc, m, PlantJacobians, ControllerJacobians, h, kappa), flip(t_vector), [0*x0; 0*z0; 0*Theta]);
    elseif strcmp(Solver, 'ODE45')
        [~, X] =  ode45(@(t, X) RHS_Backward_Function(t, X, Theta, t_vector, yr, Q, x, z, Plant_Parameters, v, p, nc, m, PlantJacobians, ControllerJacobians, h, kappa), flip(t_vector), [0*x0; 0*z0; 0*Theta]);
    else
        error('The solver type should be either "ODE15s" or "ODE45".');
    end
    X = X';
    X = flip(X,2);
    grad = X(1:p,1) + R * Theta;
end

function dX = RHS_Backward_Function(t, X, Theta, t_vector, yr, Q, x, z, Plant_Parameters, v, p, nc, m, PlantJacobians, ControllerJacobians, h, kappa)
    Q = Cell_Interpolate(t_vector, Q, t);
    yr = Vector_Interpolate(t_vector, yr, t);
    x = Vector_Interpolate(t_vector, x, t);
    z = Vector_Interpolate(t_vector, z, t);
    y = h(x, Plant_Parameters);
    u = kappa(z, y, v, Theta);
    lambda = X(p+1:end, 1);
    [A, B, C] = PlantJacobians(x, u, Plant_Parameters);
    [Ac, Bc, Cc, Dc, BTheta, CTheta] = ControllerJacobians(z, y, v, Theta);
    dlambda = -[A + B*Dc*C, B*Cc; Bc*C, Ac]' * lambda - [C'*Q*(y-yr); zeros(nc,m)];
    dxi = -[B*CTheta; BTheta]' * lambda;
    dX = [dxi; dlambda];
end