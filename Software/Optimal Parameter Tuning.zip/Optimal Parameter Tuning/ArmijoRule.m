function Step = ArmijoRule(tau, beta, Step_0, s, grad, Theta, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver, Q, R, yr)
[~, ~, ~, y] = Simulate_ClosedLoop(Theta, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver);
J = ComputeCostFunctional(Theta, y, t_vector, yr, Q, R);
Projection = grad' * s;
Step = Step_0;
Theta_new = Theta + Step * s;
[~, ~, ~, y_new] = Simulate_ClosedLoop(Theta_new, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver);
J_new = ComputeCostFunctional(Theta_new, y_new, t_vector, yr, Q, R);
while(J_new > J + Step * beta * Projection)
    Step = tau * Step;
    Theta_new = Theta + Step * s;
    [~, ~, ~, y_new] = Simulate_ClosedLoop(Theta_new, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver);
    J_new = ComputeCostFunctional(Theta_new, y_new, t_vector, yr, Q, R);
end
end
