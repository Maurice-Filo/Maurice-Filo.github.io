function J = ComputeCostFunctional(Theta, y, t_vector, yr, Q, R)
%This function computes the cost functional
%   J(y;Theta) = (1/2) \int_0^T (y(t) - yr(t))^T Q(t) (y(t) - yr(t)) dt + (1/2) Theta^T R Theta
    J = 0;
    for k = 1 : length(t_vector)
        e_k = y(:,k) - yr(:,k);
        J = J + e_k' * Q{k} * e_k;
    end
    dt = t_vector(2) - t_vector(1);
    J = 0.5 * J * dt + 0.5 * Theta' * R * Theta;
end

