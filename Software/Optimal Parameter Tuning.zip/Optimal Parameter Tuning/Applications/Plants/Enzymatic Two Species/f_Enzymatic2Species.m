function dx = f_Enzymatic2Species(x, u, Plant_Parameters)
%This function is the right hand side of the following differential
%equation:
%           dx1dt = u - gamma x1
%           dx2dt = kx1 - gamma x2
gamma = Plant_Parameters.gamma;
k = Plant_Parameters.k;
x1 = x(1);
x2 = x(2);
dx = [u - gamma*x1; k*x1 - gamma*x2];
end

