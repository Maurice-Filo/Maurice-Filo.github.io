function Plant_Parameters = Generate_Plant_Parameters_Enzymatic2Species(gamma, k)
%This function generates the parameters for the following plant
%           dx1dt = u - gamma x1
%           dx2dt = kx1 - gamma x2
    Plant_Parameters.n = 2;                 % Number of states
    Plant_Parameters.m = 1;                 % Number of outputs
    Plant_Parameters.q = 1;                 % Number of inputs
    Plant_Parameters.gamma = gamma;
    Plant_Parameters.k = k;
end

