function y = h_Enzymatic2Species(x, ~)
%This function is the output equation given by
%           y = x2
    y = x(2);
end

