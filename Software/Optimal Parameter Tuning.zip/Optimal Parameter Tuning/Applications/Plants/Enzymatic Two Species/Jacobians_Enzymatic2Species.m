function [A, B, C] = Jacobians_Enzymatic2Species(~, ~, Plant_Parameters)
% This function computes the Jacobians (w.r.t. x and u) for the right hand
% side of the following differential equations:
%           dx1dt = u - gamma x1
%           dx2dt = kx1 - gamma x2
%               y = x2
    gamma = Plant_Parameters.gamma;
    k = Plant_Parameters.k;
    A = [-gamma, 0; k, -gamma];
    B = [1; 0];
    C = [0, 1];
end

