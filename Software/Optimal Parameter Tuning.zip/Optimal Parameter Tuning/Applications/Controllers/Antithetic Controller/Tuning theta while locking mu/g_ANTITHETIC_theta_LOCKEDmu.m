function dz = g_ANTITHETIC_theta_LOCKEDmu(z,y,v,Theta)
% The Antithetic Controller has a locked mu = yss*theta. 
% The tuning parameter vector is Theta = theta.
% The constant parameter vector is v = [yss; eta; nu; gamma].
% The Antithetic Controller has y as an input and produces u as an output:
%           z = [z1; z2], dz/dt = g(z,y,v;Theta); u = kappa(z,y,v;Theta)
%           dz1/dt = mu - eta*z1*z2 - gamma*z1
%           dz2/dt = theta*y - eta*z1*z2 - gamma*z2
%                u = nu*z1
% where mu is locked: mu = yss*theta, and yss is the desired set-point that
% is achieved in case there is no dilution (i.e. gamma = 0).
% This function is the right hand side of the differential equations.
    yss = v(1); 
    eta = v(2);
    gamma = v(4);
    z1 = z(1);
    z2 = z(2);
    theta = Theta;
    dz = [theta * yss - eta * z1 * z2 - gamma * z1; theta * y - eta * z1 * z2 - gamma * z2];
end


