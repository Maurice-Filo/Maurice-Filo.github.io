function [Ac, Bc, Cc, Dc, BTheta, CTheta] = JACOBIANS_ANTITHETIC_theta_LOCKEDmu(z, y, v, Theta)
% The Antithetic Controller has a locked mu = yss*theta. 
% The tuning parameter vector is Theta = theta.
% The constant parameter vector is v = [yss; eta; nu; gamma].
% The Antithetic Controller has y as an input and produces u as an output:
%           z = [z1; z2], dz/dt = g(z,y,v;Theta); u = kappa(z,y,v;Theta)
%           dz1/dt = mu - eta*z1*z2 - gamma*z1
%           dz2/dt = theta*y - eta*z1*z2 - gamma*z2
%                u = nu*z1
% where mu is locked: mu = yss*theta, and yss is the desired set-point that
% is achieved in case there is no dilution (i.e. gamma = 0).
% This function computes the Jacobians (w.r.t. z, y and Theta) for the right hand
% side of the equations, i.e.
%   Ac = dg/dz   Bc = dg/dy   Cc = dkappa/dz    Dc = dkappa/dy
%   BTheta = dg/dTheta      CTheta = dkappa/dTheta
    yss = v(1);
    eta = v(2);
    nu = v(3);
    gamma = v(4);
    theta = Theta;
    z1 = z(1); z2 = z(2);
    Ac = [-eta*z2 - gamma, -eta*z1; -eta*z2, -eta*z1 - gamma];
    Bc = [0; theta];
    Cc = [nu, 0];
    Dc = 0;
    BTheta = [yss; y];
    CTheta = 0;
end



