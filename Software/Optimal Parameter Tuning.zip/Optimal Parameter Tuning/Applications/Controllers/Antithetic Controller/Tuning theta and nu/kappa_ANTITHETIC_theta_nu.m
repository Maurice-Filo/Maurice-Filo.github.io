function u = kappa_ANTITHETIC_theta_nu(z,~,~,Theta)
% The tuning parameter vector is Theta = [theta; nu].
% The constant parameter vector is v = [mu; eta; gamma].
% The Antithetic Controller has y as an input and produces u as an output:
%           z = [z1; z2], dz/dt = g(z,y,v;Theta); u = kappa(z,y,v;Theta)
%           dz1/dt = mu - eta*z1*z2 - gamma*z1
%           dz2/dt = theta*y - eta*z1*z2 - gamma*z2
%                u = nu*z1
% This function is the right hand side of the output equation
% where nu is fixed and is the second entry of the vector Theta
    nu = Theta(2);
    z1 = z(1);
    u = nu * z1;
end


