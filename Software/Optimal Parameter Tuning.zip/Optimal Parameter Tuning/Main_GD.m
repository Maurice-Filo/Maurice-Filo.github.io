%% Clear Workspace
close all
clc
clear

%% Specifying the Plant
f = @f_Enzymatic2Species;
h = @h_Enzymatic2Species;
PlantJacobians = @Jacobians_Enzymatic2Species;
Plant_Parameters = Generate_Plant_Parameters_Enzymatic2Species(1,1); % gamma and k
x0 = [0; 0];

%% Specifying the Controller
% % Tuning theta of the Antithetic Controller with locked mu
% g = @g_ANTITHETIC_theta_LOCKEDmu;
% kappa = @kappa_ANTITHETIC_theta_LOCKEDmu;
% ControllerJacobians = @JACOBIANS_ANTITHETIC_theta_LOCKEDmu;
% v = GENERATE_v_ANTITHETIC_theta_LOCKEDmu(10,100,1,0); % yss,eta,nu,gamma
% z0 = [0; 0];
% N_Parameters = 1;

% % Tuning theta of the Antithetic Controller
% g = @g_ANTITHETIC_theta;
% kappa = @kappa_ANTITHETIC_theta;
% ControllerJacobians = @JACOBIANS_ANTITHETIC_theta;
% v = GENERATE_v_ANTITHETIC_theta(10,100,1,0.5); % mu,eta,nu,gamma
% z0 = [0; 0];
% N_Parameters = 1;

% % Tuning theta and nu of the Antithetic Controller mu locked
% yss = 10;
% eta = 100;
% gamma = 0;
% g = @g_ANTITHETIC_theta_nu_LOCKEDmu;
% kappa = @kappa_ANTITHETIC_theta_nu_LOCKEDmu;
% ControllerJacobians = @JACOBIANS_ANTITHETIC_theta_nu_LOCKEDmu;
% v = GENERATE_v_ANTITHETIC_theta_nu_LOCKEDmu(yss,eta,gamma);
% z0 = [0; 0];
% N_Parameters = 2;

% Tuning theta and nu of the Antithetic Controller
mu = 10;
eta = 100;
gamma = 0.5;
g = @g_ANTITHETIC_theta_nu;
kappa = @kappa_ANTITHETIC_theta_nu;
ControllerJacobians = @JACOBIANS_ANTITHETIC_theta_nu;
v = GENERATE_v_ANTITHETIC_theta_nu_LOCKEDmu(mu,eta,gamma);
z0 = [0; 0];
N_Parameters = 2;

%% Specifying the Optimization Parameters
% Initial Guess
Theta_0 = ones(N_Parameters,1);
% Armijo Rule Parameters
beta = 0.3; tau = 0.5; Step_0 = 0.001; Step_MIN = 1e-5;
% Stopping Conditions
Nmax = 1000; NORMTOL = 1e-5;
% Time Horizon
tf = 100; dt = 0.1; t_vector = 0 : dt : tf;
% Desired Output
t1 = 5;
t2 = 15;
yss = 10;
index1 = find(t_vector >= t1, 1);
index2 = find(t_vector >= t2, 1);
yr = yss * ones(1, length(t_vector));
yr(1:index1) = (yss / t1) * t_vector(1:index1);
% Error Penalty
Q = cell(1,length(t_vector));
q = zeros(1,length(t_vector));
for k = 1 : length(t_vector)
    if k < index1
        Q{k} = 1;
    elseif (k >= index1) && (k < index2)
        Q{k} = 1;
    else
        Q{k} = 1;
    end
    q(k) = Q{k};
end
% Parameter Size Penalty
R = 0;
% ODE Solver
Solver = 'ODE23s';

%% Gradient Descent Algorithm
J_History = zeros(1,Nmax);
Step_History = zeros(1, Nmax);
Theta_History = zeros(length(Theta_0), Nmax);
NORM = 1;
i = 1;
Theta_i = Theta_0;
Step_i = Step_0;
while(NORM > NORMTOL) && (i <= Nmax) && (Step_i > Step_MIN)
    Theta_History(:,i) = Theta_i;
    [grad_i, y_i] = Gradient_Parameters(Theta_i, t_vector, yr, Q, R, Plant_Parameters, v, x0, z0, f, g, h, kappa, PlantJacobians, ControllerJacobians, Solver);
    Step_i = ArmijoRule(tau, beta, Step_0, -grad_i, grad_i, Theta_i, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver, Q, R, yr);
    Theta_i = Theta_i - Step_i * grad_i;
    NORM = grad_i' * grad_i;    
    J_History(i) = ComputeCostFunctional(Theta_i, y_i, t_vector, yr, Q, R);
    Step_History(i) = Step_i;
    i = i+1
end
J_History(i:end) = [];
Step_History(i:end) = [];
Theta_History(:,i:end) = [];

%% Plot Results
LineWidth = 2;
FontSize = 12;
figure();
Handle_1 = subplot(2,2,[1,2]);
    plot(Handle_1, t_vector, y_i, 'LineWidth', LineWidth); 
    hold on;
    plot(Handle_1, t_vector, yr, 'LineWidth', LineWidth, 'LineStyle', '--', 'Color', 'k');
    Handle_1.XGrid = 'on';
    Handle_1.YGrid = 'on';
    Handle_1.XMinorGrid = 'on';
    Handle_1.YMinorGrid = 'on';
    Handle_1.XLabel.String = 'Time';
    Handle_1.YLabel.String = 'Output';
    Handle_1.XLim = [0 t_vector(end)];
    Handle_1.FontSize = FontSize;

Handle_3 = subplot(2,2,3);
    plot(Handle_3, 1:length(J_History), J_History, 'color', 'k', 'LineWidth', LineWidth);
    Handle_3.XGrid = 'on';
    Handle_3.YGrid = 'on';
    Handle_3.XMinorGrid = 'on';
    Handle_3.YMinorGrid = 'on';
    Handle_3.XLabel.String = 'Iterations';
    Handle_3.YLabel.String = 'Performance Index';
    Handle_3.XLim = [1, length(J_History)];
    Handle_3.FontSize = FontSize;
    Handle_3.YScale = 'log';

Handle_4 = subplot(2,2,4);
    plot(Handle_4, 1:length(Step_History), Step_History, 'color', 'k', 'LineWidth', LineWidth);
    Handle_4.XGrid = 'on';
    Handle_4.YGrid = 'on';
    Handle_4.XMinorGrid = 'on';
    Handle_4.YMinorGrid = 'on';
    Handle_4.XLabel.String = 'Iterations';
    Handle_4.YLabel.String = 'Step Size';
    Handle_4.XLim = [1, length(Step_History)];
    Handle_4.FontSize = FontSize;
    Handle_4.YScale = 'log';