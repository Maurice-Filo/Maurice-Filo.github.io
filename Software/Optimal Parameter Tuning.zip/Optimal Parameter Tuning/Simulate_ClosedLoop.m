function [x, z, u, y] = Simulate_ClosedLoop(Theta, f, g, h, kappa, v, x0, z0, t_vector, Plant_Parameters, Solver)
%This function simulates the closed loop system for a given parameter
%vector Theta of the feedback controller.
%               dxdt = f(x,u);              x(0) = x0
%                  y = h(x)
%               dzdt = g(z,y,v;Theta);      z(0) = z0
%                  u = kappa(z,y,v;Theta)
    n = Plant_Parameters.n;
    m = Plant_Parameters.m;
    q = Plant_Parameters.q;
    Nt = length(t_vector);
    
    if strcmp(Solver, 'ODE15s')
        [~, X] = ode15s(@(t, X) F(t, X, Theta, f, g, kappa, h, v, n, Plant_Parameters), t_vector, [x0; z0]);
    elseif strcmp(Solver, 'ODE23s')
        [~, X] = ode23s(@(t, X) F(t, X, Theta, f, g, kappa, h, v, n, Plant_Parameters), t_vector, [x0; z0]);
    elseif strcmp(Solver, 'ODE45')
        [~, X] = ode45(@(t, X) F(t, X, Theta, f, g, kappa, h, v, n, Plant_Parameters), t_vector, [x0; z0]);
    else
        error('The solver type should be either "ODE15s" or "ODE45".');
    end
    X = X';
    x = X(1:n,:);
    z = X(n+1:end,:);
    y = zeros(m,Nt);
    u = zeros(q,Nt);
    for k = 1 : length(t_vector)
        u(:,k) = kappa(z(:,k),y(:,k),v,Theta);
        y(:,k) = h(x(:,k));
    end
end

function dX = F(~, X, Theta, f, g, kappa, h, v, n, Plant_Parameters)
    x = X(1:n, 1);
    z = X(n+1:end, 1);
    y = h(x, Plant_Parameters);
    u = kappa(z, y, v, Theta);
    dx = f(x, u, Plant_Parameters);
    dz = g(z, y, v, Theta);
    dX = [dx; dz];
end

